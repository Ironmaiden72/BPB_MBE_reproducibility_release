# Paper 0 v0.8 source

Working draft for the HAL corpus release.

This version adds the corpus-release architecture: Paper 0 is the foundational HR -> BPB/MBE dictionary, and Papers I--VII are downstream companion tests. The source keeps the guardrail that companion observational results are not premises of the Paper 0 derivation.

Build with:

```bash
latexmk -pdf -interaction=nonstopmode main.tex
```


## v0.9 corpus-release additions

This source bundle includes a `release_index/` directory with the stage-1 root release artefacts used by Paper 0 v0.9:

- `00_MANIFEST_CORPUS.csv`
- `00_CLAIMS_INDEX.csv`
- `00_RELEASE_NOTES.md`
- `00_REVIEWER_ROUTE.md/csv`
- `00_RELEASE_TODO.csv`
- `00_RELEASE_STAGE1_QA.md`

These files are navigation and audit infrastructure. Scientific claims remain governed by the paper text and their source-lock artefacts.
