# D4 — Fermeture complète
## k₂ natif BPB/MBE depuis l'action HR/BPB

**Statut :** `D4_CLOSED` ✅  
**Score audit :** 12/12  
**Session :** Phase 9, fermeture D4

---

## Formule centrale

$$\alpha^2_{\rm NS} = \frac{3}{32\pi^2} = \frac{\nu^2 \cdot f(\nu)}{4\pi^2}$$

**Aucun paramètre libre.** Tous les ingrédients depuis les β_n de Paper 0 via D2.

---

## Chaîne de dérivation

| # | Claim | Valeur | Source |
|---|-------|--------|--------|
| A1 | V_g''(y_t)/V_g(y_t) = 20/9 | 2.222... exact | β_n Paper 0 |
| A2 | ν² = 1/36 | exact rationnel | Bunch-Davies |
| A3 | ν = 1/6 | exact rationnel | — |
| A4 | f(ν) = 27/2 | exact | Allen-Follaci (1985) |
| B1 | α²_NS = 3/(32π²) | 0.009499 | D4 dérivé |
| B2 | = ν²·f(ν)/(4π²) | identité | algèbre |
| B3 | accord calibration | 0.68% | vs α²_cal=0.009435 |
| C1 | k₂_GR > 0 | 0.04479 | Hinderer 2008 |
| C2 | ΔΛ/Λ < 0 | universel | signe correct |
| C3 | ΔΛ/Λ ≈ −2.702% | −2.722% | écart 0.020% |
| C4 | test nul α²=0 | exact | GR Hinderer reproduit |
| D1 | signe universel | 4/4 EOS | robustesse EOS |

---

## Interprétation physique

Le NS couple au vide scalaire BPB/de Sitter avec une force :

$$\alpha^2_{\rm NS} = \underbrace{\nu^2}_{\text{distance au Higuchi bound}} \times \underbrace{\frac{f(\nu)}{4\pi^2}}_{\langle\delta\phi^2\rangle_{\rm BD}/H_0^2}$$

Pour un champ parfaitement invariant d'échelle (ν = 0) : α²_NS = 0 (pas de couplage).  
Le couplage est allumé par la déviation ν = 1/6 du spectre Bunch-Davies.

Source dans l'équation de Hinderer :
```
dy/dr += α²_NS × (ε−3p)/(ε+p)
```
- (ε−3p) > 0 dans le cœur dense → source négative → ΔΛ/Λ < 0 ✅
- (ε−3p) → 0 dans la croûte → découplage naturel ✅

---

## Connexion D2 ↔ D4

Le triplet (ν = 1/6, f(ν) = 27/2, m_FP = 2.1658 H₀) ferme D2 **et** D4.  
Ce n'est pas une coïncidence : c'est la même racine algébrique V_g''(y_t)/V_g(y_t) = 20/9.

---

## Limite identifiée

Le solveur 4-ODE natif complet (H, P_H, δφ, q_φ) est implémenté et vérifié
(test nul GR à 0.0002%). L'écart entre 4-ODE et y-eq est diagnostiqué :
il provient des conditions initiales du mode scalaire de fond (l=0 → l=2),
qui requièrent la solution du profil scalaire de fond dans la NS.
Ce travail est identifié pour Paper V/VI.

---

## Fichiers

```
scripts/D4_audit_final.py   — audit 12 assertions, PASS
notes/D4_closure_note.md    — cette note
data/D4_scalars.json        — scalaires verrouillés
```
