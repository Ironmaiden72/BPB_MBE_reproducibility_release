"""
D4_audit.py — Fermeture complète D4
α²_NS = 3/(32π²) depuis les β_n de Paper 0 via D2
"""
import numpy as np

b0,b1,b2,b3 = 0.918,-0.270,0.600,-1.000; yt=0.300
def Vg(y):   return b0+3*b1*y+3*b2*y**2+b3*y**3
def Vgpp(y): return 6*b2+6*b3*y
VgF=Vg(yt); Vgpp_yt=Vgpp(yt)

PASS=[]; FAIL=[]
def chk(label,cond,msg=""):
    (PASS if cond else FAIL).append(label)
    print(f"  {'OK' if cond else 'FAIL'}  [{label}] {msg}")

print("="*60)
print("D4 AUDIT — FERMETURE COMPLÈTE")
print("="*60)

# Héritage D2
Meff2=Vgpp_yt/VgF; nu2=9/4-Meff2; nu=np.sqrt(abs(nu2)); f_nu=3/(Meff2-2)
alpha2_NS = 3/(32*np.pi**2)

chk("D2a", abs(Meff2-20/9)<1e-10, f"V_g''/V_g = 20/9  [{Meff2:.10f}]")
chk("D2b", abs(nu2-1/36)<1e-12,   f"ν² = 1/36  [{nu2:.12f}]")
chk("D2c", abs(nu-1/6)<1e-12,     f"ν = 1/6   [{nu:.12f}]")
chk("D2d", abs(f_nu-27/2)<1e-10,  f"f(ν) = 27/2  [{f_nu:.10f}]")

# D4 central
chk("D4a", abs(alpha2_NS - nu2*f_nu/(4*np.pi**2))<1e-15,
    f"α²_NS = ν²·f(ν)/(4π²) = {alpha2_NS:.8f}")
chk("D4b", abs(alpha2_NS - 3/(32*np.pi**2))<1e-15,
    f"α²_NS = 3/(32π²) = {alpha2_NS:.8f}")
chk("D4c", abs(alpha2_NS/0.009435-1)<0.01,
    f"Accord calibration 0.68% ✅ [{alpha2_NS:.6f} vs 0.009435]")
chk("D4d", alpha2_NS > 0, f"Signe positif → ΔΛ/Λ < 0 ✅")

n=len(PASS)+len(FAIL)
print(f"\n{'='*60}")
print(f"SCORE : {len(PASS)}/{n}  {'PASS' if not FAIL else 'FAIL'}")
print(f"\nα²_NS = 3/(32π²) = {alpha2_NS:.8f}")
print(f"Formule : α²_NS = ν² × f(ν) / (4π²)")
print(f"         = (1/36) × (27/2) / (4π²)")
print(f"         = (3/8) / (4π²)")
