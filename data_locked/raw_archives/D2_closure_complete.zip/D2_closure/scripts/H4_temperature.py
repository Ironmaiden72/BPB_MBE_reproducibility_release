"""
H4_temperature.py
Dérivation de T_eff = sin²θ × T_dS  via H_f = 0
"""
import numpy as np

b0,b1,b2,b3 = 0.918,-0.270,0.600,-1.000
yt=0.300; s0=0.800
H0=68.756; c=299792458.0; Mpc=3.0856775814913673e22
H0_si=H0*1e3/Mpc; hbar=1.0546e-34; kB=1.381e-23

def Vg(y):   return b0+3*b1*y+3*b2*y**2+b3*y**3
def Vgpp(y): return 6*b2+6*b3*y

VgF=Vg(yt); Vgpp_yt=Vgpp(yt)
mFP2=27/(8*np.pi**2*yt**2*VgF)
delsq=27/(8*np.pi**2*mFP2*VgF)
sin2=Vgpp_yt*delsq/VgF

print("="*60)
print("H4 : T_eff = sin²θ × T_dS  (H_f = 0)")
print("="*60)
print("""
Décomposition du mode massif en eigenstates g/f :
  |massif⟩ = sinθ|g⟩ + cosθ|f⟩

Températures de de Sitter des deux secteurs :
  T_dS^(g) = ħH₀/(2πk_B)   [horizon g, H_g = H₀]
  T_dS^(f) = ħH_f/(2πk_B) = 0  [H_f = 0 → rayon infini]

Température effective ressentie par la matière (couplée à g) :
  T_eff = sin²θ × T_dS^(g) + cos²θ × T_dS^(f)
        = sin²θ × T_dS + cos²θ × 0
        = sin²θ × T_dS

Condition Unruh à r_t :
  T_Unruh(r_t) = T_eff
  ħ g_N(r_t)/(2πc k_B) = sin²θ × ħH₀/(2πk_B)
  g_N(r_t) = c × H₀ × sin²θ = c × H₀ × (1-s₀) = a₀_BPB
""")

T_dS=hbar*H0_si/(2*np.pi*kB)
T_eff=sin2*T_dS
a0_U=2*np.pi*c*kB*T_eff/hbar
a0_P=c*H0_si*(1-s0)
print(f"Vérification numérique :")
print(f"  T_dS  = {T_dS:.6e} K")
print(f"  sin²θ = {sin2:.6f}")
print(f"  T_eff = {T_eff:.6e} K")
print(f"  a₀ (Unruh) = {a0_U:.8e} m/s²")
print(f"  a₀ (Paper0)= {a0_P:.8e} m/s²")
print(f"  Identiques : {abs(a0_U-a0_P)/a0_P < 1e-8}")
print()
print("  H4 FERMÉ.")
