from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root = Path(__file__).resolve().parents[1]
data = root / 'data'
figs = root / 'figs'
figs.mkdir(exist_ok=True)

raw = pd.read_csv(data/'raw_chi2.csv')
mapper = pd.read_csv(data/'mapper_physical_peak.csv')
prior = pd.read_csv(data/'prior_penalties.csv')
tau = pd.read_csv(data/'tau_proxy.csv')

# Fig 1 raw chi2
plt.figure(figsize=(7.2,4.4))
x = np.arange(len(raw))
plt.bar(x, raw['chi2_uvlf_display'], label='UVLF')
plt.bar(x, raw['chi2_rhostar_display'], bottom=raw['chi2_uvlf_display'], label=r'$\rho_\star$')
for i, v in enumerate(raw['chi2_raw_display']):
    plt.text(i, v+0.25, f'{v:.4f}', ha='center', va='bottom', fontsize=9)
plt.xticks(x, raw['model'])
plt.ylabel(r'$\chi^2$')
plt.title(r'Raw UVLF+$\rho_\star$ likelihood: LCDM remains better')
plt.legend(frameon=False)
plt.tight_layout()
plt.savefig(figs/'fig1_raw_chi2_from_csv.pdf')
plt.savefig(figs/'fig1_raw_chi2_from_csv.png', dpi=200)
plt.close()

# Fig 2 mapper peak
plt.figure(figsize=(8.0,4.8))
ax1 = plt.gca()
x = np.arange(len(mapper))
ax1.bar(x-0.18, mapper['M_UV_peak'], width=0.36, label=r'$M_{UV,peak}$')
ax1.set_ylabel(r'$M_{UV,peak}$')
ax1.invert_yaxis()
ax1.set_xticks(x)
ax1.set_xticklabels(mapper['model'])
ax2 = ax1.twinx()
ax2.bar(x+0.18, mapper['log10_M_peak'], width=0.36, label=r'$\log_{10}M_{peak}$', alpha=0.5)
ax2.set_ylabel(r'$\log_{10}(M_{peak}/M_\odot)$')
ax1.set_title('Same peak UV light, different host-mass scale')
lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1+lines2, labels1+labels2, frameon=False, loc='upper center')
plt.tight_layout()
plt.savefig(figs/'fig2_peak_mapper_from_csv.pdf')
plt.savefig(figs/'fig2_peak_mapper_from_csv.png', dpi=200)
plt.close()

# Fig 3 prior breakdown
plt.figure(figsize=(7.2,4.4))
x=np.arange(len(prior))
plt.bar(x, prior['chi2_Mpeak'], label=r'$M_{peak}$')
plt.bar(x, prior['chi2_prior_other'], bottom=prior['chi2_Mpeak'], label='other prior terms')
for i, v in enumerate(prior['chi2_prior_total']):
    plt.text(i, v+0.15, f'{v:.2f}', ha='center', fontsize=9)
plt.xticks(x, prior['model'])
plt.ylabel(r'$\chi^2_{prior}$')
plt.title(r'Prior penalty: LCDM is dominated by low $M_{peak}$')
plt.legend(frameon=False)
plt.tight_layout()
plt.savefig(figs/'fig3_prior_breakdown_from_csv.pdf')
plt.savefig(figs/'fig3_prior_breakdown_from_csv.png', dpi=200)
plt.close()

# Fig 4 raw vs data+prior
plt.figure(figsize=(7.4,4.4))
width=0.35
x=np.arange(len(prior))
plt.bar(x-width/2, prior['chi2_raw_display'], width, label='raw data')
plt.bar(x+width/2, prior['chi2_data_prior_display'], width, label='data + physicality')
plt.xticks(x, prior['model'])
plt.ylabel(r'$\chi^2$')
plt.title('Raw likelihood versus physicality-regularised diagnostic')
plt.legend(frameon=False)
plt.tight_layout()
plt.savefig(figs/'fig4_data_prior_from_csv.pdf')
plt.savefig(figs/'fig4_data_prior_from_csv.png', dpi=200)
plt.close()

# Fig 5 tau proxy
plt.figure(figsize=(8.0,4.8))
x=np.arange(len(tau))
err_low = tau['tau_q50']-tau['tau_q16']
err_high = tau['tau_q84']-tau['tau_q50']
plt.errorbar(x, tau['tau_q50'], yerr=[err_low, err_high], fmt='o', capsize=4, label='posterior q16/q50/q84')
plt.scatter(x, tau['tau_best'], marker='s', label='best')
plt.axhline(0.09, linestyle='--', linewidth=1, label=r'$\tau=0.09$')
plt.xticks(x, tau['model'])
plt.ylabel(r'$\tau$')
plt.title('Reionization optical-depth proxy')
plt.legend(frameon=False)
plt.tight_layout()
plt.savefig(figs/'fig5_tau_proxy_from_csv.pdf')
plt.savefig(figs/'fig5_tau_proxy_from_csv.png', dpi=200)
plt.close()

# Fig 6 source traceability flow
plt.figure(figsize=(9.5,2.8))
plt.axis('off')
steps = ['CSV sources', 'Mapper equations', 'Prior terms', 'Figures', 'Paper V v0.3']
xs = np.linspace(0.08,0.92,len(steps))
for i,(x0,label) in enumerate(zip(xs,steps)):
    plt.text(x0,0.55,label,ha='center',va='center',bbox=dict(boxstyle='round,pad=0.35',fc='white',ec='black'))
    if i < len(steps)-1:
        plt.annotate('',xy=(xs[i+1]-0.07,0.55),xytext=(x0+0.07,0.55),arrowprops=dict(arrowstyle='->'))
plt.title('v0.3 source-traceability chain')
plt.tight_layout()
plt.savefig(figs/'fig6_source_traceability.pdf')
plt.savefig(figs/'fig6_source_traceability.png', dpi=200)
plt.close()

print(f'Wrote figures to {figs}')
