# Paper VI / E_G T1 — r_Wδ ≈ sqrt(a_bg) theory-closure gate

## Status

**P6_T1_RWDELTA_SQRT_ABG_NUMERIC_PASS_STRONG**

This is a non-destructive theory/audit gate. It runs no ACT/Planck/E_G likelihood and touches no NS files.

## Locked numerical relation

| quantity | value |
|---|---:|
| free projected r_Wδ | 0.630864746000 |
| a_bg | 0.403687948000 |
| sqrt(a_bg) | 0.635364421415 |
| r_Wδ^2 | 0.397990327746 |
| r_Wδ - sqrt(a_bg) | -0.004499675415 |
| relative Δr/sqrt(a_bg) | -0.708204% |
| r_Wδ^2 - a_bg | -0.005697620254 |
| relative Δr²/a_bg | -1.411392% |

## χ² comparison

| hypothesis | χ² | Δχ² vs free r |
|---|---:|---:|
| free global r | 1.358943 | 0.000000 |
| r = sqrt(a_bg) | 1.367488 | 0.008545 |
| r = 1 - a_bg | 1.862853 | 0.503910 |
| r = sqrt(1-a_bg) | 9.791644 | 8.432701 |
| r = a_bg | 23.141918 | 21.782975 |

The fixed relation `r_Wδ = sqrt(a_bg)` is numerically indistinguishable from the free-r solution in this compressed diagnostic: Δχ² = 0.008545.

## Minimal conditional theory statement

Assume the projected Weyl response can be decomposed into a matter-correlated component and a BPB-private/decorrelated component,

```text
W = sqrt(a_bg) δ_m + sqrt(1-a_bg) ξ_W,
```

with `corr(δ_m, ξ_W)=0` and equal normalized variances in the projected diagnostic window. Then

```text
P_Wδ / sqrt(P_WW P_δδ) = sqrt(a_bg),
```

so the effective cross-correlation coefficient measured by E_G is

```text
r_Wδ = sqrt(a_bg).
```

Under this closure, `a_bg` is not fitted to E_G. It is inherited from the BPB/HR background dictionary and interpreted as the correlated Weyl-power fraction. The residual `1-a_bg` is the decorrelated Weyl auto-power fraction.

## Claim wording candidate

The projected E_G diagnostic does not require a freely fitted Weyl--matter correlation coefficient. The best-fit value `r_Wδ = 0.630865` is reproduced, to sub-percent accuracy and with only Δχ² = 0.008545, by the dictionary-tied closure `r_Wδ = sqrt(a_bg) = 0.635364`. This suggests that the BPB transition parameter controls the matter-correlated fraction of the Weyl response, while `1-a_bg` corresponds to decorrelated Weyl auto-power.

## Caveat

This is not yet an action-level derivation. The next required step is to derive the Weyl decomposition from the BPB/HR perturbation sector, or to show why the equality is only an empirical coincidence of the compressed E_G windows.

## Files written

- `paperVI_EG_T1_rWdelta_sqrt_abg_summary.csv`
- `paperVI_EG_T1_r_hypothesis_comparison.csv`
- `paperVI_EG_T1_decisions.csv`
- `paperVI_EG_T1_rWdelta_sqrt_abg_gate.json`
- `paperVI_EG_T1_rWdelta_sqrt_abg_gate.md`
- `fig_P6_T1_rWdelta_sqrt_abg.png/pdf`

