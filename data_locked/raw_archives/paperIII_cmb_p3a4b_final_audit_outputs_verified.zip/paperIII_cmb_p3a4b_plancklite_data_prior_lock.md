# Paper III CMB P3-A4b — Planck-lite data/prior decomposition lock

## Status

**P3_A4B_PLANCKLITE_DATA_PRIOR_LOCK_PASS**

## Claim

`P3.CLAIM.PLANCKLITE.02`: the Planck-lite residual penalty of the strict face-minus branch is calibration-normalization driven, not acoustic-shape driven.

## Source files

- `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9700.json`
- `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9760.json`

## Best rows

- Planck sanity best: ns=0.970, A_Planck=0.988996412978, chi2_total=791.314859498286, chi2_data=771.942231120593, chi2_prior=19.372628377693
- Strict C_s_surv0 best: ns=0.976, A_Planck=0.982163373471, chi2_total=817.791437749467, chi2_data=766.888198399886, chi2_prior=50.903239349581

## Decomposition

- Δχ²_total = 26.476578251181
- Δχ²_data(TTTEEE) = -5.054032720707
- Δχ²_APlanck_prior = 31.530610971888

## Locked interpretation

The strict branch improves the Planck-lite TT/TE/EE spectral-shape/data term, but is penalized by the absolute A_Planck calibration-normalization prior. This strengthens the Paper III wording from 'survives' to 'better shape, calibration-normalization penalty'.

## Caveat

Planck-lite TTTEEE diagnostic only; not a full official Planck nuisance/foreground MCMC.

## Isolation

NS touched = NO. Likelihood run = NO.
