# Paper III v0.4.1 QA / hotfix

Status: source-only HAL hotfix. PDF intentionally not included.

Changes relative to v0.4:

- Promoted the Planck-lite data/prior decomposition earlier in the argument.
- Added explicit wording that the strict-branch residual penalty is dominated by the APlanck calibration-normalization prior, not by the acoustic-shape data term.
- Replaced the body-level source-lock gate list with a compact audit pointer.
- Moved the detailed P3-A0--P3-A4b gate inventory to an appendix.
- Replaced the vague ACT DR6 bibliography entry with explicit Qu et al. (2024) ApJ 962, 112 and Madhavacheril et al. (2024) ApJ 962, 113 entries.
- No locked scientific numbers changed.

Guardrails preserved:

- Not an official full Planck nuisance/foreground MCMC closure.
- Not an official combined ACT+Planck likelihood.
- Not a final derived Weyl-window kernel.

Compile check: local pdflatex run completed successfully; generated manuscript PDF was excluded from the source-only ZIP. Output length: 8 pages.
