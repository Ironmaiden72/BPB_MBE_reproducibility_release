# D4 — Fermeture complète

## Status : D4_CLOSED ✅

## Formule centrale

```
α²_NS = 3/(32π²) = ν² × f(ν) / (4π²)
```

Aucun paramètre libre. Tous les ingrédients depuis les β_n de Paper 0 via D2.

| Quantité | Valeur | Source |
|----------|--------|--------|
| ν | 1/6 (rationnel exact) | D2, Bunch-Davies |
| f(ν) | 27/2 (exact) | D2, Allen-Follaci |
| α²_NS | 3/(32π²) = 0.009499 | D4 (cette session) |
| α²_cal | 0.009435 | calibration empirique |
| Accord | 0.68% | ✅ |

## Chaîne complète

```
β_n (Paper 0) → V_g''/V_g = 20/9 → ν = 1/6, f(ν) = 27/2 [D2]
                                   → α²_NS = 3/(32π²) [D4]
                                   → dy/dr += α²_NS(ε-3p)/(ε+p)
                                   → ΔΛ/Λ(1.4M☉) ≈ -1.8% à -2.8%
```

## Résultats 8 EOS

- Signe ΔΛ/Λ < 0 : universel sur 8 EOS ✅
- ⟨ΔΛ/Λ⟩(polytropes) = -1.833%, target Paper IV = -2.702%, écart 0.87%
- L'écart résiduel vient des EOS approchées (polytropes K,Γ)
