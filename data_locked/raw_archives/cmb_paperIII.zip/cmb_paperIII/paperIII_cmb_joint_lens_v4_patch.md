# Paper III CMB P3-A1b — joint lensing v4 extraction patch

## Status

**P3_A1B_JOINT_LENS_V4_EXTRACTION_PATCH_PASS**

This gate fixes the source-match extraction for `P3.JOINTLENS.01` by using `chi2_Planck_lensing` as the Planck lensing column.

Safety: read-only on `outputs/cmb`; writes only to `outputs/cmb_paperIII`; no ACT/Planck likelihood run; no NS touch.

## Source files

- Grid: `outputs/cmb/cmb15a_v4_joint_act_planck_scalar_amp_map1782.grid.csv`
- Refs: `outputs/cmb/cmb15a_v4_joint_act_planck_scalar_amp_map1782.refs.csv`

Rows scanned: **4001**

## Canonical extracted values

| selector | amp_phi | Sigma_eff | chi2_ACT | chi2_Planck_lensing | chi2_joint |
|---|---:|---:|---:|---:|---:|
| ACT-only best | 1.043000 | 1.021273715 | 14.153599 | 10.198317 | 24.351916 |
| Planck-only best | 1.075000 | 1.036822068 | 15.908702 | 8.742460 | 24.651162 |
| Joint scalar best | 1.057000 | 1.028105053 | 14.478027 | 9.243264 | 23.721292 |

Separate minima sum: **22.896060**  
Joint scalar penalty: **0.825232**

Expected-value check: **PASS**

## Gate decisions

| decision | value |
|---|---|
| P3.JOINTLENS.01 extraction | PASS |
| chi2_Planck_lensing column detected | PASS |
| planck_best found | PASS |
| joint_best found | PASS |
| source-match corrected | PASS |
| likelihood run | NO |
| NS touched | NO |
| write scope | outputs/cmb_paperIII only |
| next gate | P3-A2 canonical table choice / figure inventory |


## Outputs

- `outputs/cmb_paperIII/paperIII_cmb_joint_lens_v4_patch.csv`
- `outputs/cmb_paperIII/paperIII_cmb_joint_lens_v4_expected_checks.csv`
- `outputs/cmb_paperIII/paperIII_cmb_joint_lens_v4_patch.json`
- `outputs/cmb_paperIII/paperIII_cmb_claim_source_lock_p3a1b_jointlens_patch.csv`
- `outputs/cmb_paperIII/paperIII_cmb_joint_lens_v4_patch.md`
