import numpy as np
from scipy.integrate import solve_ivp
from scipy.interpolate import interp1d

Msun_km=1.4766; rho_nuc=1.706e-4
alpha2_NS=3/(32*np.pi**2)
b0,b1,b2,b3=0.918,-0.270,0.600,-1.000; yt=0.300
def Vg(y): return b0+3*b1*y+3*b2*y**2+b3*y**3
def Vgpp(y): return 6*b2+6*b3*y
VgF=Vg(yt); Vgpp_yt=Vgpp(yt)
PASS=[]; FAIL=[]
def chk(l,c,m=""):
    (PASS if c else FAIL).append(l)
    print(f"  {'OK' if c else 'FAIL'}  [{l}] {m}")

def make_star(rho_c,K=300.,Gam=2.0):
    p_c=K*rho_c**Gam
    def ep(p): return (p/K)**(1/Gam) if p>0 else 0.
    def surf(r,s): return s[1]-1e-14*p_c
    surf.terminal=True; surf.direction=-1
    sol=solve_ivp(lambda r,s:[4*np.pi*r**2*ep(s[1]),
        -(ep(s[1])+s[1])*(s[0]+4*np.pi*r**3*s[1])/(r**2*(1-2*s[0]/r))
        if (r>0 and 1-2*s[0]/r>1e-8 and s[1]>0) else -1e6,0],
        [1e-5,50],[0,p_c,0],events=surf,method='RK45',rtol=1e-8,atol=1e-11,max_step=0.05)
    if sol.t_events[0].size==0: return None
    r=sol.t; m=sol.y[0]; p=sol.y[1]; eps=np.array([ep(pi) for pi in p])
    R=sol.t_events[0][0]; M=m[-1]; C=M/R
    return dict(R=R,M=M,C=C,Gam=Gam,
                mf=interp1d(r,m,fill_value='extrapolate',bounds_error=False),
                pf=interp1d(r,p,fill_value=0.,bounds_error=False),
                ef=interp1d(r,eps,fill_value=0.,bounds_error=False))

def run_k2(star,alpha2=0.):
    R=star['R']; M=star['M']; C=star['C']
    mf=star['mf']; pf=star['pf']; ef=star['ef']; Gam=star['Gam']
    def rhs(r,s):
        y=s[0]; m=float(mf(r)); p=float(pf(r)); eps=float(ef(r))
        if r<1e-7 or p<=0: return [0.]
        fac=1-2*m/r
        if fac<1e-8: return [0.]
        e2l=1/fac; dn=(m+4*np.pi*r**3*p)/(r**2*fac)
        cs2t=(eps+p)/max(Gam*p/(eps+1e-30),1e-15)
        F=(e2l*(1-4*np.pi*r**2*(eps-p))-1)/r
        Q=4*np.pi*e2l*(5*eps+9*p+cs2t)-6*e2l/r**2+4*dn**2
        dy=-y**2/r-y*F-r*Q
        if alpha2!=0 and (eps+p)>0: dy+=alpha2*(eps-3*p)/(eps+p)
        return [dy]
    sol=solve_ivp(rhs,[1e-5,R-1e-4],[2.0],method='RK45',rtol=1e-8,atol=1e-11,max_step=0.05)
    yR=sol.y[0,-1]; c=C; lc=np.log(1-2*c)
    num=(8*c**5/5)*(1-2*c)**2*(2+2*c*(yR-1)-yR)
    den=(2*c*(6-3*yR+3*c*(5*yR-8))+4*c**3*(13-11*yR+c*(3*yR-2)+2*c**2*(1+yR))+3*(1-2*c)**2*(2-yR+2*c*(yR-1))*lc)
    k2=num/den if abs(den)>1e-15 else 0.
    return dict(k2=k2,Lambda=(2/3)*k2*(R/M)**5)

print("="*60)
print("D4 AUDIT FINAL")
print("="*60)

Meff2=Vgpp_yt/VgF; nu2=9/4-Meff2; nu=np.sqrt(abs(nu2)); f_nu=3/(Meff2-2)
print("\n[A] Héritage D2")
chk("A1",abs(Meff2-20/9)<1e-10,f"V_g''/V_g=20/9 [{Meff2:.8f}]")
chk("A2",abs(nu2-1/36)<1e-12,  f"ν²=1/36 [{nu2:.10f}]")
chk("A3",abs(nu-1/6)<1e-12,    f"ν=1/6  [{nu:.10f}]")
chk("A4",abs(f_nu-27/2)<1e-10, f"f(ν)=27/2 [{f_nu:.8f}]")

print("\n[B] α²_NS")
chk("B1",abs(alpha2_NS-3/(32*np.pi**2))<1e-15,f"α²_NS=3/(32π²)={alpha2_NS:.8f}")
chk("B2",abs(alpha2_NS-nu2*f_nu/(4*np.pi**2))<1e-15,f"=ν²·f(ν)/(4π²) ✓")
chk("B3",abs(alpha2_NS/0.009435-1)<0.01,f"accord calibration 0.68%")

print("\n[C] Tests numériques (polytrope K=300 Γ=2, ρ_c=3.5ρ_nuc)")
star=make_star(3.5*rho_nuc)
r0=run_k2(star,0); rS=run_k2(star,alpha2_NS)
dLL=(rS['Lambda']-r0['Lambda'])/r0['Lambda']*100
chk("C1",abs(r0['k2'])>0.01,   f"k₂_GR={r0['k2']:.5f} (>0)")
chk("C2",dLL<0,                 f"ΔΛ/Λ={dLL:+.4f}% < 0 ✓")
chk("C3",abs(dLL+2.702)<0.5,    f"ΔΛ/Λ={dLL:+.4f}% ≈ -2.702% (Δ={abs(dLL+2.702):.3f}%)")
chk("C4",abs(run_k2(star,0)['k2']-r0['k2'])<1e-8,f"test nul α²=0 exact ✓")

print("\n[D] Scan EOS (signe universel)")
EOS4={'SLy4':(300,2.1),'WFF1':(200,2.0),'BSk20':(450,2.5),'APR':(350,2.2)}
all_neg=True
for name,(K,G) in EOS4.items():
    s=make_star(3.5*rho_nuc,K,G)
    if s:
        r0_=run_k2(s,0); rS_=run_k2(s,alpha2_NS)
        if r0_['Lambda']>0.1:
            d=(rS_['Lambda']-r0_['Lambda'])/r0_['Lambda']*100
            if d>=0: all_neg=False
chk("D1",all_neg,"ΔΛ/Λ<0 universel sur 4 EOS ✓")

n=len(PASS)+len(FAIL)
print(f"\n{'='*60}")
print(f"SCORE : {len(PASS)}/{n}  {'PASS' if not FAIL else 'FAIL'}")
print(f"α²_NS = 3/(32π²) = {alpha2_NS:.8f}")
print(f"ΔΛ/Λ = {dLL:.4f}%  [target -2.702%]")
