# D3 — Statut après session

## Status : D3_CONDITIONAL_UNDER_BIFACE_TRANSITION

## Ce qui est établi ✅

1. **Mécanisme r_Wδ = √a_bg** (algèbre pure, exact)
   - tan²(θ_W) = (1-a_bg)/a_bg → cos²(θ_W) = a_bg → r_Wδ = √a_bg

2. **Argument Λ-like vs dynamique** (physique exacte)
   - ρ_surv ∝ s₀ VgF : composante Λ-like, δρ_surv = 0, pas de corrélation
   - ρ_split ∝ (1-s₀) VgF : dynamique, δρ_split ≠ 0, corrèle avec δ

3. **Comelli+2012 Eq.(4.1) ne s'applique pas** (identifié)
   - c = 0 dans le fond BPB/MBE (H_f = 0 pour tout a)
   - Route correcte : EFT BPB split-relic

## Ce qui reste ouvert ❌

**Condition analytique pour a_bg depuis les β_n seuls**

| Condition testée | a_bg calculé | Écart |
|-----------------|--------------|-------|
| ΔV_g/(s₀VgF) = (1-a)/a | pas de solution | — |
| ρ_split/ρ_m = (1-a)/a | 0.729 | 81% |
| (Ω_m/VgF)^{1/3} | 0.593 | 47% |
| (ΔΩ/Ω_m)^{1/3} | 0.986 | 144% |

**a_bg = 0.4037 reste empirique** (fit MAP1782/SPARC).
Sa dérivation depuis l'action HR requiert la dérivation T9D/T10b de Paper VI.

## Wording paper-safe

> D3 ferme le mécanisme r_Wδ = √a_bg conditionnellement à la définition
> biface de a_bg. La composante surviving (s₀) étant Λ-like (δρ=0), seule
> la composante split (1-s₀) corrèle avec δ, donnant tan²(θ_W) = 
> ρ_split/ρ_m(a_bg) = (1-a_bg)/a_bg par définition de a_bg dans Paper VI.
> La dérivation action-level de a_bg depuis les β_n seuls reste le verrou
> résiduel de D3, requérant la dérivation complète T9D/T10b.
