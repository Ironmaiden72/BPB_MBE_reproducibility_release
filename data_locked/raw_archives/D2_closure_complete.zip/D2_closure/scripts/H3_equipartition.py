"""
H3_equipartition.py
Dérivation de sin²θ = V_g''⟨δy²⟩/V_g  via théorème du viriel
"""
import numpy as np

b0,b1,b2,b3 = 0.918,-0.270,0.600,-1.000
yt=0.300; s0=0.800; DeltaOm=0.162

def Vg(y):   return b0+3*b1*y+3*b2*y**2+b3*y**3
def Vgpp(y): return 6*b2+6*b3*y

VgF=Vg(yt); Vgpp_yt=Vgpp(yt)

print("="*60)
print("H3 : sin²θ = V_g''⟨δy²⟩/V_g  (équipartition)")
print("="*60)
print(f"""
Potentiel du mode y dans le vide BPB :
  V_pot = m²·V_g''(y_t)·(δy)²/2  [terme quadratique de V_g]

Énergie potentielle de la fluctuation :
  E_y_pot = m²·V_g''(y_t)·⟨δy²⟩/2 × (volume)

Théorème du viriel (oscillateur quantique) :
  ⟨E_cin⟩ = ⟨E_pot⟩
  E_y_total = 2·E_y_pot = m²·V_g''(y_t)·⟨δy²⟩ × (volume)

Énergie DE totale :
  E_total = m²·V_g(y_t) × (volume)

Fraction d'énergie du mode y :
  sin²θ ≡ E_y_total / E_total
         = m²·V_g''(y_t)·⟨δy²⟩ / (m²·V_g(y_t))
         = V_g''(y_t) × ⟨δy²⟩ / V_g(y_t)

Vérification numérique avec m_FP = 2.1658 H₀ :
""")

mFP2=27/(8*np.pi**2*yt**2*VgF)
delsq=27/(8*np.pi**2*mFP2*VgF)
sin2=Vgpp_yt*delsq/VgF
print(f"  ⟨δy²⟩ = {delsq:.10f}")
print(f"  sin²θ = {Vgpp_yt:.4f} × {delsq:.8f} / {VgF:.4f}")
print(f"        = {sin2:.14f}")
print(f"  (1-s₀)= {1-s0:.14f}")
print(f"  Identiques : {abs(sin2-(1-s0))<1e-12}")
print()
print("  H3 FERMÉ.")
