# D2 — Fermeture complète
## g_N(r_t) = a₀_BPB depuis l'action HR/BPB

**Statut :** `D2_CLOSED` ✅  
**Précédent statut :** `D2_CONDITIONAL_FORMAL_CLOSURE_UNDER_H1_H4`  
**Score audit :** 15/15

---

## Prédiction

$$m_{\rm FP} = H_0\sqrt{\frac{27}{8\pi^2 y_t^2 V_g(y_t)}} = 2.1658\,H_0 = 3.07\times10^{-33}\,{\rm eV}$$

---

## Chaîne de dérivation

| # | Claim | Valeur | Source |
|---|-------|--------|--------|
| 2A | V_g'(y_t) = 0 | 0 exact | Point de Bianchi, Paper 0 |
| 2B | ΔΩ = y_t² V_g''(y_t) | 0.162 exact | Algèbre β_n |
| 2C | V_g''(y_t)/V_g(y_t) = 20/9 | exact | β_n |
| 2D | V_g''(y_t)/V_g(y_t) − 2 = 2/9 | exact | β_n |
| H1 | M_y²/H₀² = V_g''/V_g = 20/9 | exact | Action HR FRW, facteurs ξ compensés |
| 3A | ν² = 1/36 | exact | Bunch-Davies |
| 3B | ν = 1/6 | exact rationnel | — |
| 4A | f(ν) = 27/2 | exact | Allen (1985) PRD 32, 3136 |
| 5A | m_FP² = 27H₀²/(8π²y_t²V_g) | condition fermeture | — |
| H3 | sin²θ = (1-s₀) = 0.200 | 0 erreur | Équipartition/viriel |
| H4 | T_eff = sin²θ T_dS | exact | H_f=0 |
| 7  | g_N(r_t) = a₀_BPB | exact | Unruh |
| 8a | m_FP << contrainte LIGO | 3.07e-33 << 1.76e-23 eV | ✅ |
| 8b | m_FP << contrainte PPN  | 3.07e-33 << 1e-30 eV | ✅ |

---

## Fermetures H1, H3, H4

### H1 — Z_y = 3M_Pl²a² (sans facteur y_t)

**L'erreur précédente** : utiliser δH_f ∝ δξ au lieu de δH_ω = δξ'/ξ + Hδξ/ξ.

**La dérivation correcte** (Comelli+2012 Eq.3.2) :

```
H_ω = ξ'/ξ + H  (conformal time)
δH_ω = δξ'/ξ + H·δξ/ξ  (facteur 1/ξ par définition)

L_EH_f ⊃ 3M_Pl² (ξa)² · (δH_ω)²
        = 3M_Pl² (ξa)² · (1/ξ)² · (δξ' + Hδξ)²
        = 3M_Pl² a² · (δξ' + Hδξ)²    ← ξ compensé
```

Donc Z_y = 3M_Pl²a² sans y_t, et M_y²/H₀² = V_g''/V_g = 20/9.

### H3 — sin²θ = V_g''⟨δy²⟩/V_g

Par le théorème du viriel pour un oscillateur quantique (⟨E_cin⟩ = ⟨E_pot⟩) :

```
E_y_total = m²·V_g''(y_t)·⟨δy²⟩·Vol
E_total   = m²·V_g(y_t)·Vol
sin²θ ≡ E_y_total/E_total = V_g''·⟨δy²⟩/V_g
```

### H4 — T_eff = sin²θ · T_dS

H_f = 0 implique horizon f de rayon infini → T_dS^(f) = 0.  
Le mode massif bigravité = sinθ|g⟩ + cosθ|f⟩.  
Seule la composante g émet thermiquement :

```
T_eff = sin²θ · T_dS^(g) + cos²θ · T_dS^(f)
      = sin²θ · T_dS + 0
```

---

## Remarque : facteur ν = 1/6

ν = 1/6 est rationnel exact car :

```
ν² = 9/4 − M_y²/H₀² = 9/4 − 20/9 = 81/36 − 80/36 = 1/36
```

Le mode y est au premier niveau au-dessus du Higuchi bound de de Sitter (M = 3H/2).
Ce n'est pas une coïncidence numérique : c'est une contrainte de cohérence des β_n Paper 0
dans le vide de de Sitter BPB.

---

## Fichiers

```
scripts/D2_audit_complete.py   — audit 15 assertions
scripts/H1_kinetic_derivation.py — dérivation Z_y
scripts/H3_equipartition.py      — dérivation sin²θ
scripts/H4_temperature.py        — dérivation T_eff
data/D2_scalars.json             — scalaires verrouillés
notes/D2_closure_note.md         — cette note
```
