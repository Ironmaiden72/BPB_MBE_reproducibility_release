# BPB/MBE reviewer route — stage 1

This file gives the fast audit route. It is not a replacement for the individual source locks.

| step | action | purpose | primary artifact | review question |
|---:|---|---|---|---|
| 0 | Read 00_README_CORPUS | Understand the map; no claim validation here. | `00_README_CORPUS.pdf` | Does the corpus state its own guardrails? |
| 1 | Check 00_MANIFEST_CORPUS | Verify that every paper has status/path/source-lock state. | `00_MANIFEST_CORPUS.csv` | Are missing manuscripts and missing source locks explicit? |
| 2 | Check 00_CLAIMS_INDEX | Pick any claim and follow source_lock_path + locked value. | `00_CLAIMS_INDEX.csv` | Can a reviewer trace claims to concrete CSV/JSON/MD locks? |
| 3 | Paper 0 kill/validate point | Derivation of the BPB/MBE dictionary and D2/a0 provenance. | `paper/paper0/main.pdf; paper/paper0/source_locks/D2_a0_closure/*` | Does the HR/BPB dictionary survive? |
| 4 | Paper I kill/validate point | Low-z joint likelihood vs LCDM and Weyl/growth separation. | `paper/paperI v2/*; outputs/cosmology/*` | Does the frozen v0.3 replacement enter the release? |
| 5 | Paper II kill/validate point | D3 projector, D5/D6 SPARC amplitude kernel, D7 CAMB mechanism. | `outputs/paperII_D3/*; outputs/paperII_D5/*; outputs/paperII_D7/*` | Does the SPARC claim remain “most gap”, not exact oracle/archive? |
| 6 | Paper III kill/validate point | ACT/Planck-lite/lensing diagnostic locks. | `outputs/cmb_paperIII/*; outputs/cmb/*` | Does the paper avoid claiming full official Planck likelihood? |
| 7 | Paper IV kill/validate point | NS strict/global and 1.4 effective tidal response. | `outputs/ns/*` | Is native k2 clearly NOT claimed? |
| 8 | Paper VI kill/validate point | E_G projected Weyl closure and T10/T10b source locks. | `outputs/paperVI_EG_theory/*` | Is the projected/conditional nature explicit? |
| 9 | Paper VII kill/validate point | Fixed a0, D2 thermal bridge, BTFR/RC support with guardrails. | `outputs/paperVII/*` | Is full SPARC RC likelihood explicitly NOT claimed? |


## Fast kill/validate logic

- Kill Paper 0 if the HR/BPB dictionary or survival-factor bridge is not internally coherent.
- Kill Paper I if the frozen low-z v0.3 likelihood cannot be source-locked.
- Kill Paper II if D3/D5/D6/D7 source locks cannot be traced or if wording claims exact archive/oracle recovery.
- Kill Paper III if CMB/Planck wording exceeds the diagnostic/full-likelihood status actually locked.
- Kill Paper IV if the NS result is worded as a native scalar-tensor Love-number solution.
- Kill Paper VI if projected E_G closure is presented as unconditional action-level closure.
- Kill Paper VII if it is presented as full SPARC RC likelihood or exact MOND/interpolation derivation.
