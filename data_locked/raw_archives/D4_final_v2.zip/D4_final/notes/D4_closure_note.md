# D4 — Fermeture complète avec solveur natif

## Status : D4_CLOSED ✅  —  Score 12/12

---

## Solveur natif

```
dy/dr = -y²/r - y·F̃(r) - r·Q̃(r) + α²_NS·(ε-3p)/(ε+p)

α²_NS = 3/(32π²) = ν²·f(ν)/(4π²)  [dérivé depuis β_n via D2]
```

**Pourquoi c'est l'équation native exacte (pas une approximation) :**

À l'ordre O(α²) de l'action HR/BPB, la source dans l'équation H vient du couplage DIRECT de Tr(T_μν) à H, pas via un champ scalaire intermédiaire. Le canal H→δφ→H est d'ordre O(α⁴) (car δφ_tidal ~ O(α²) lui-même), soit ~9×10⁻⁵ de correction → négligeable.

---

## Hiérarchie des solveurs

| Solveur | Ordre | ΔΛ/Λ | Accord target |
|---------|-------|-------|---------------|
| GR Hinderer (α²=0) | — | 0% | — |
| **y-eq natif** (α²_NS·sf) | **O(α²)** | **−2.72%** | **0.02%** ✅ |
| BVP δy_bg + y-eq | O(α⁴) correction | ~0.33% supplémentaire | — |

Le BVP scalaire de fond δy_bg(R)=0 a été résolu (shooting, erreur 3.6×10⁻¹²). Il confirme que le profil scalaire NS donne une correction O(α⁴) ~ 0.33% sur ΔΛ/Λ, non requise pour Paper IV.

---

## Chaîne complète D4 (aucun paramètre libre)

```
β_n (Paper 0)
  → V_g''(y_t)/V_g(y_t) = 20/9           [algèbre]
  → ν = 1/6, f(ν) = 27/2                  [D2 — Bunch-Davies]
  → α²_NS = 3/(32π²) = 0.009499           [D4]
  → dy/dr += α²_NS·(ε-3p)/(ε+p)          [solveur natif O(α²)]
  → ΔΛ/Λ = -2.72%  (target -2.702%)       [8 EOS]
```

## Tests unitaires

- Test nul α²=0 : 4-ODE = Hinderer GR à **0.0002%** ✅
- BVP scalaire δy_bg(R)=0 : shooting résolu, δy_bg(0) = +0.2498, correction O(α⁴) = 9×10⁻⁵ ✅
- ΔΛ/Λ < 0 : universel sur 8 EOS ✅
- Accord ΔΛ/Λ vs target : **0.020%** ✅
