# Paper III CMB P3-A4 - canonical figure generation

## Status

**P3_A4_CANONICAL_FIGURES_GENERATED**

Safety: no ACT/Planck likelihood run; no NS touch; writes only to `outputs/cmb_paperIII`.

## Generated primary figures

| figure | PDF | PNG | caption lock |
|---|---|---|---|
| `Fig_P3_1_ACT_lensing_gate` | `/mnt/data/p3a4_test_repo/outputs/cmb_paperIII/figures/fig_P3_1_ACT_lensing_gate.pdf` | `/mnt/data/p3a4_test_repo/outputs/cmb_paperIII/figures/fig_P3_1_ACT_lensing_gate.png` | ACT DR6 lenslike CMB dictionary gate. The vanilla late-density CMB mapping is catastrophically disfavoured, while the strict face-minus/Kprimary dictionary remains close to the Planck sanity point and improves under a small positive Weyl-auto amplitude profile. |
| `Fig_P3_2_PlanckLite_high_ell` | `/mnt/data/p3a4_test_repo/outputs/cmb_paperIII/figures/fig_P3_2_PlanckLite_high_ell.pdf` | `/mnt/data/p3a4_test_repo/outputs/cmb_paperIII/figures/fig_P3_2_PlanckLite_high_ell.png` | Planck-lite high-ell TTTEEE proxy. The strict C_s_surv0 dictionary improves the profiled high-ell chi2 relative to the Planck sanity point in this lite diagnostic, while the vanilla dictionary fails by thousands in chi2. |
| `Fig_P3_3_joint_lensing_scalar_closure` | `/mnt/data/p3a4_test_repo/outputs/cmb_paperIII/figures/fig_P3_3_joint_lensing_scalar_closure.pdf` | `/mnt/data/p3a4_test_repo/outputs/cmb_paperIII/figures/fig_P3_3_joint_lensing_scalar_closure.png` | Scalar-amplitude closure for ACT DR6 and Planck CMB-marginalized lensing. ACT-only and Planck-only windows prefer nearby positive amplitudes, and one common amp_phi=1.057 gives a joint penalty of only Delta chi2=0.825 relative to separate minima. |

## Gate decisions

| decision | value |
|---|---|
| P3-A4 figure generation | PASS |
| Primary figures generated | 3/3 |
| P3-A1b joint patch used | YES |
| NS touched | NO |
| likelihood run | NO |
| next gate | P3-A5 LaTeX figure insertion / table rendering |

## Outputs

- `/mnt/data/p3a4_test_repo/outputs/cmb_paperIII/paperIII_cmb_p3a4_figure_outputs.csv`
- `/mnt/data/p3a4_test_repo/outputs/cmb_paperIII/paperIII_cmb_p3a4_figure_checks.csv`
- `/mnt/data/p3a4_test_repo/outputs/cmb_paperIII/paperIII_cmb_p3a4_figure_generation.json`
- `/mnt/data/p3a4_test_repo/outputs/cmb_paperIII/paperIII_cmb_p3a4_figure_generation.md`
