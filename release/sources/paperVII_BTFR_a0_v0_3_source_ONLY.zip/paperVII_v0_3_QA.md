# Paper VII v0.3 QA — source-only

## Status

`PAPER_VII_V0_3_SOURCE_ONLY_CORPUS_AWARE_PASS`

## Changes from v0.2

- Updated manuscript label to v0.3 / HAL corpus-aware release lock.
- Added a `Corpus placement and release navigation` section pointing to `00_README_CORPUS`, `00_MANIFEST_CORPUS.csv`, `00_CLAIMS_INDEX.csv`, and `00_REVIEWER_ROUTE`.
- Added `release_index/` folder with the stage-1 corpus navigation files.
- Added minimal bibliography for MOND, SPARC, RAR, emergent-gravity comparison, and Planck baseline context.
- Added explicit MOND/RAR/SPARC comparison wording while keeping the Paper-VII guardrail: no full SPARC RC likelihood, no unique interpolation derivation, no unconditional MOND action limit.
- Duplicated data/source-lock filenames to `paperVII_v0_3_*` while preserving all locked scientific values from P7-A7.
- No manuscript PDF included in the delivery ZIP.

## Scientific changes

None. Numeric locks are unchanged from P7-A7:

- `a0_BPB = 1.367856592595e-10 m/s²`
- `s_surv0 = 0.7956924397708606`
- BTFR primary `n=118`, median residual `-0.056007711329 dex`, RMS `0.295494277101 dex`
- P7-A5 raw RAR fractional improvement `0.911207525795`
- P7-A6b primary best `a0/a0_BPB = 0.807075252405`
- P7-A6b active38 best `a0/a0_BPB = 0.486722101981`, shape-only guardrail

## Compile QA

Local `pdflatex` compile performed in a temporary directory. Output PDF was generated for QA only and excluded from the source ZIP.
