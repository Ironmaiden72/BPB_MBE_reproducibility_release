# Paper VI v0.2 QA / changelog

## Status

**P6V02_EG_AUTO_CROSS_DENSITY_PROJECTOR_LOCK_PASS_WITH_GUARDRAIL**

Source-only release. The manuscript PDF was compiled locally for QA but is excluded from the delivery ZIP.

## Compile QA

- Command: `pdflatex -interaction=nonstopmode -halt-on-error paperVI_EG_weyl_cross_v0_2.tex` twice
- Result: PASS
- Rendered pages in local QA PDF: 9
- Unresolved references/citations: none detected
- Remaining warnings: hyperref PDF-string warnings from math in title/metadata; minor overfull/underfull boxes only

## Scientific changes vs v0.1

- Added corpus-aware release navigation and reviewer-route framing.
- Added projected density-weighted closure: `r_Wdelta = sqrt(a_bg) = 0.635364421415`.
- Kept the v0.1 compressed diagnostic: `r_Wdelta_free = 0.633563`, `chi2_EG = 0.191532`.
- Added T8 amplitude-space support: `<X,X>/<A,A> = 0.397990327336`, relative offset from `a_bg` = `-1.411392%`.
- Added explicit false-route guardrail: Wenzl 19-bin shape/model-space projector is not used as proof because the shape space is effectively one-dimensional.
- Added D3b sub-percent support: `s0`-weighted diagnostic predicts `a_bg` within `0.532556%` to `0.680002%`, but is not exact.
- Added claim/source lock, numeric locks, and decisions CSVs.
- Added bibliography entries for E_G and ACT DR6 lensing references.

## Guardrails retained

- Not a full projected `C_l^{kappa g}`, `C_l^{gg}`, `beta`, covariance likelihood.
- Not a universal constant claim for every future E_G window.
- Not an action-level perturbation proof of the density-weighted mixing relation.
- The D2 relation `tan^2(theta_W)=rho_f_eff/rho_g_eff` remains the explicit source-match guardrail.

## Key file hashes

| file | exists | bytes | sha256 |
|---|---:|---:|---|
| `paperVI_EG_weyl_cross_v0_2.tex` | True | 21983 | `4c464a3c0d9586f51eb0d7efbec6053df168dcd25615dd1c95cb83cdde1377a9` |
| `data/paperVI_v0_2_numeric_locks.csv` | True | 1583 | `a5c6752c5a0d41172ccd1111de12682d2098151a3a7429fe9f13a0b9fdd29567` |
| `data/paperVI_v0_2_claim_source_lock.csv` | True | 1692 | `19b0db1e3abe40dee4832554db7246744c0b0e06896cfaaaf3dc9981bad25de3` |
| `data/paperVI_v0_2_decisions.csv` | True | 953 | `835c07aa503b746aea4e2f480973c2fabe7d37d5c39803db2ae33b44b884ba31` |
| `scripts/make_paperVI_v0_2_figures.py` | True | 3842 | `2bb5dde74268ab50e1daf461492d1c258886a4def79c38c68e0970a844cbacb9` |

## Delivery note

The ZIP contains LaTeX source, figures, data/source-lock CSVs, the figure-generation script, and release-index files. It intentionally excludes the compiled manuscript PDF.
