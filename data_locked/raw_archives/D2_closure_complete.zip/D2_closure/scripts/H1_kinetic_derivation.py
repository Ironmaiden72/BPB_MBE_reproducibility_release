"""
H1_kinetic_derivation.py
Dérivation de Z_y = 3M_Pl²a² depuis l'action HR FRW
Montre que les facteurs ξ = y_t se compensent.
"""
import numpy as np

b0,b1,b2,b3 = 0.918,-0.270,0.600,-1.000
yt=0.300

def Vg(y):   return b0+3*b1*y+3*b2*y**2+b3*y**3
def Vgpp(y): return 6*b2+6*b3*y

VgF=Vg(yt); Vgpp_yt=Vgpp(yt)

print("="*60)
print("H1 : Z_y = 3M_Pl²a²  (Comelli+2012 convention)")
print("="*60)
print("""
Convention (Comelli+2012 Eq.3.1-3.2) :
  g : ds² = a²[-dτ² + dx²]
  f : ds̃² = ω²[-c²dτ² + dx²]  avec ξ = ω/a

Hubble f :
  H_ω = ω'/ω = ξ'/ξ + H

Fond BPB (H_ω = 0) :
  ξ'/ξ = -H  →  ξ' = -H ξ

Perturbation δξ :
  δH_ω = δ(ξ'/ξ) + δH = δξ'/ξ + H δξ/ξ

  NB : le 1/ξ vient de la DÉFINITION de δH_ω,
       pas d'un choix de variable.

Terme cinétique EH secteur f :
  L_EH_f ⊃ 3M_Pl² ω² (H_ω)²
           = 3M_Pl² (ξa)² (H_ω)²

Au fond (H_ω = 0), seul le terme quadratique survit :
  L_EH_f ⊃ 3M_Pl² (ξa)² (δH_ω)²
           = 3M_Pl² (ξa)² [δξ'/ξ + H δξ/ξ]²
           = 3M_Pl² (ξa)² (1/ξ)² [δξ' + H δξ]²
           = 3M_Pl² a² [δξ' + H δξ]²

Les facteurs ξ se compensent : (ξa)² × (1/ξ)² = a²

→ Z_y = 3M_Pl²a²  SANS facteur ξ = y_t
""")

# Masse effective
print("Masse effective de δξ :")
print("  L_pot = m² V_g''(ξ₀) a³ (δξ)²/2")
print("  M_y² × Z_y = m² V_g''(ξ₀) a²")
print("  M_y² = m² V_g''(y_t) / (3M_Pl²)")
print()
print("Friedmann g (domination DE) :")
print("  3M_Pl² H₀² = m² V_g(y_t)  →  m² = 3M_Pl² H₀²/V_g(y_t)")
print()
print("Ratio M_y²/H₀² :")
Meff2=Vgpp_yt/VgF
print(f"  M_y²/H₀² = V_g''(y_t)/V_g(y_t)")
print(f"           = {Vgpp_yt:.4f}/{VgF:.4f}")
print(f"           = {Meff2:.10f}")
print(f"           = 20/9 = {20/9:.10f}")
print(f"  Ecart : {abs(Meff2-20/9):.2e}  PASS={abs(Meff2-20/9)<1e-10}")
print()
print("  Le facteur y_t est ABSENT car (ξa)²×(1/ξ)²=a².")
print("  H1 FERMÉ.")
