# Paper III CMB P3-A2 — canonical table choice and figure inventory

## Status

**P3_A2_CANONICAL_TABLES_FIGURE_INVENTORY_DONE**

Safety: read-only on `outputs/cmb` and `outputs/cmb_paperIII` inputs; writes only to `outputs/cmb_paperIII`; no ACT/Planck likelihood run; no NS touch.

## Canonical paper tables

| paper table | status | role | key numbers | wording level |
|---|---|---|---|---|
| `T_CMB_ACT_DR6_lenslike` | CANONICAL | Full ACT DR6 lenslike diagnostic table | Planck chi2_ACT=13.951140; vanilla chi2_ACT=227.520768; Kprimary amp1 chi2_ACT=17.470021; Kprimary CMB8 amp chi2_ACT=14.156104; scan best amp_PhiPhi=1.043, Sigma_eff=1.021273715, chi2_ACT=14.153599 | Full ACT DR6 lenslike diagnostic; not a standalone full cosmological MCMC. |
| `T_CMB_PlanckLite_high_ell` | CANONICAL | Primary Planck-lite TTTEEE high-ell table | Planck best_full_chi2=765.869165; C_s_surv0 best_full_chi2=749.191768; delta=-16.677397; C_Zbest best_full_chi2=777.286828; vanilla best_full_chi2=8851.940269, vanilla delta=8086.071104 | Planck-lite/proxy high-ell TTTEEE; not official full Planck nuisance likelihood. |
| `T_CMB_PlanckLite_high_low_tau` | CANONICAL_SUPPORTING | High-ell + native lowT/lowE + tau/As extension table | Planck total=1182.553918; C_s_surv0 total=1164.645118; delta_total=-17.908799; delta_highl=-17.386802; delta_lowT_lowE=-0.521997 | Planck-lite plus low-ell proxy/supporting closure. |
| `T_CMB_Planck_lensing_CMBmarged` | CANONICAL | Planck CMB-marginalized lensing official-formula diagnostic | Planck best_chi2=9.181939; BPB strict best_amp_phi=1.075, Sigma_eff=1.036822068, best_chi2=8.742460; vanilla best_chi2=20.544514 | Official Planck lensing CMBmarged formula diagnostic; scalar amplitude profiled. |
| `T_CMB_Planck_lensing_kernel_three_band` | SUPPORTING_NOT_PRIMARY | Kernel-shape diagnostic beyond scalar amplitude | BPB three-band chi2=2.235355; Planck three-band chi2=2.343225; vanilla three-band chi2=5.042761 | Supporting forensic/kernel diagnostic; do not oversell as fitted physical kernel. |
| `T_CMB_Joint_ACT_Planck_scalar_lensing` | CANONICAL_PATCHED_P3A1B | Joint scalar Weyl-auto amplitude closure table | ACT-only amp_phi=1.043, chi2_ACT=14.153599; Planck-only amp_phi=1.075, chi2_Planck_lensing=8.742460; Joint amp_phi=1.057, chi2_joint=23.721292; separate_minima_sum=22.896060; penalty=0.825232 | Scalar-amplitude diagnostic closure; not a full official combined ACT+Planck likelihood. |

## Recommended figure plan

| figure id | priority | content | generation status |
|---|---|---|---|
| `Fig_P3_1_ACT_lensing_gate` | PRIMARY | ACT DR6 lenslike chi2 comparison: Planck_PR4, vanilla late-density, Kprimary amp1, Kprimary scan best. | TO_GENERATE_FROM_TABLES |
| `Fig_P3_2_PlanckLite_high_ell` | PRIMARY | Planck-lite high-ell TTTEEE bar/waterfall: Planck_PR4, C_s_surv0, C_Zbest, vanilla. | TO_GENERATE_FROM_TABLES |
| `Fig_P3_3_joint_lensing_scalar_closure` | PRIMARY | ACT-only, Planck-only and joint scalar amp_phi minima with joint penalty annotation. | TO_GENERATE_FROM_PATCHED_P3A1B_TABLE |
| `Fig_P3_4_optional_proxy_contact_sheet` | OPTIONAL_APPENDIX_OR_SUPPLEMENT | Existing TT/EE/TE, peak and lensing proxy PNGs as a compact appendix/contact-sheet if desired. | OPTIONAL_EXISTING_FIGURES |

Existing CMB/proxy image files found by A0 inventory: **9**

### Existing proxy/diagnostic figures

| path | status | paper use |
|---|---|---|
| `outputs/cmb/cmb_lensing_weyl_proxy_map1782.amp_profiled.png` | EXISTING_PROXY_OPTIONAL | Optional proxy figure: CMB lensing/Weyl proxy bridge |
| `outputs/cmb/cmb_lensing_weyl_proxy_map1782.raw.png` | EXISTING_PROXY_OPTIONAL | Optional proxy figure: CMB lensing/Weyl proxy bridge |
| `outputs/cmb/cmb_peak_proxy_budget_map1782.png` | EXISTING_PROXY_OPTIONAL | Optional proxy figure: acoustic peak budget |
| `outputs/cmb/cmb_peak_proxy_budget_map1782.rel.png` | EXISTING_PROXY_OPTIONAL | Optional proxy figure: acoustic peak budget |
| `outputs/cmb/cmb_polarization_proxy_map1782.EE.png` | EXISTING_PROXY_OPTIONAL | Optional proxy figure: TT/EE/TE polarization sanity |
| `outputs/cmb/cmb_polarization_proxy_map1782.TE.png` | EXISTING_PROXY_OPTIONAL | Optional proxy figure: TT/EE/TE polarization sanity |
| `outputs/cmb/cmb_polarization_proxy_map1782.TT.png` | EXISTING_PROXY_OPTIONAL | Optional proxy figure: TT/EE/TE polarization sanity |
| `outputs/cmb/cmb_tt_shape_proxy_map1782.amp_profiled.png` | EXISTING_PROXY_OPTIONAL | Optional proxy figure: TT shape sanity / face-minus shape non-crash |
| `outputs/cmb/cmb_tt_shape_proxy_map1782.raw.png` | EXISTING_PROXY_OPTIONAL | Optional proxy figure: TT shape sanity / face-minus shape non-crash |

## Gate decisions

- **P3-A2 canonical table choice:** PASS
- **P3-A2 figure inventory:** PASS
- **P3-A1b joint patch incorporated:** PASS
- **claims paper-ready:** CANONICAL_TABLES_SELECTED_FIGURES_PENDING
- **next_gate:** P3-A3 wording lock or figure generation

## Open items

| id | item | status | note |
|---|---|---|---|
| P3A2.O01 | Generate publication-grade figures from canonical tables | OPEN_NEXT | Recommended first figures: ACT gate, Planck-lite high-ell waterfall, joint scalar closure. |
| P3A2.O02 | Patch source_tables joint summary or explicitly supersede it | OPEN_LOW_RISK | paperIII_cmb_source_tables.csv still contains old Joint_ACT_Planck_v4_summary with joint_best=None; P3-A1b patch is authoritative. |
| P3A2.O03 | Freeze wording levels | OPEN_NEXT | ACT full lenslike diagnostic; Planck-lite proxy/lite; Planck lensing official-formula diagnostic; joint lensing scalar-amplitude diagnostic closure. |

## Outputs

- `outputs/cmb_paperIII/paperIII_cmb_p3a2_canonical_tables.csv`
- `outputs/cmb_paperIII/paperIII_cmb_p3a2_figure_inventory.csv`
- `outputs/cmb_paperIII/paperIII_cmb_p3a2_figure_plan.csv`
- `outputs/cmb_paperIII/paperIII_cmb_p3a2_open_items.csv`
- `outputs/cmb_paperIII/paperIII_cmb_p3a2_canonical_tables_fig_inventory.json`
- `outputs/cmb_paperIII/paperIII_cmb_p3a2_canonical_tables_fig_inventory.md`
