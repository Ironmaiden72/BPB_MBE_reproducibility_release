# Paper 0 D2 acceleration-scale source lock -- v0.7

Status: `D2_INTERNAL_SOURCE_LOCK_PASSED_V07 / D2_ACCELERATION_SCALE_BRIDGE_CLOSED_IN_PROGRAM`.

This source lock closes the BPB acceleration-scale descendant

`a0_BPB = c H0 (1-s_surv0)`

inside the documented HR/BPB y-mode normalization chain. It does not close the full response hierarchy, does not derive a unique MOND interpolation function, and does not replace the later SPARC rotation-curve likelihood/guardrail papers.

Core locked values:

| Quantity | Value |
|---|---:|
| y_t | 0.300 |
| V_g(y_t) | 0.810 |
| V_g''(y_t) | 1.800 |
| DeltaOmega | 0.162 |
| s_surv,HR rounded | 0.800 |
| s_surv,0 exact corpus lock | 0.7956924397708606 |
| 1-s_surv,0 exact | 0.2043075602291394 |
| V_g''/V_g | 20/9 |
| nu | 1/6 |
| f(nu) | 27/2 |
| m_FP/H0 | 2.165824447871323 |
| m_FP | 3.0711390670815356e-33 eV |
| <delta y^2> | 0.09 |
| sin^2 theta HR rounded | 0.2 |
| H0 primary | 68.91059068227626 km/s/Mpc |
| T_dS | 2.714866240842e-30 K |
| T_eff | 5.546676980150e-31 K |
| a0_BPB | 1.367856592595e-10 m/s^2 |

Audit scripts executed successfully; see `D2_audit_run.log`.
