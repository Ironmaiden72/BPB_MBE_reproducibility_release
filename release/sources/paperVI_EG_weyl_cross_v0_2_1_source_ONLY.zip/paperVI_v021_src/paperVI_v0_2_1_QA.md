# Paper VI v0.2.1 QA — source-only hotfix

Status: **HAL-ready source hotfix**

## Changes vs v0.2

- Added an explicit interpretation of the very small compressed $E_G$ chi-square: two compressed bins and one effective free cross-response parameter mean $\chi^2=0.191532$ is a compressed consistency diagnostic, not a full projected-likelihood goodness-of-fit.
- Added the same guardrail to the conclusion bullet.
- Updated title/version string from v0.2 to v0.2.1.
- No scientific numbers changed.
- No figures regenerated.

## Compile check

Local LaTeX compile performed with `pdflatex` on `paperVI_EG_weyl_cross_v0_2_1.tex`. PDF was intentionally excluded from the distribution ZIP.

## Guardrail reinforced

The paper now states explicitly that the small two-bin value could invite questions about compression, under-estimated errors, and model flexibility. The answer recorded in the body is that Paper VI is a compressed auto/cross diagnostic; the full test remains a projected $C_\ell^{\kappa g}$, $C_\ell^{gg}$, RSD, bias, and covariance likelihood.
