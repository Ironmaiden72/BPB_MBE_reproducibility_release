# Paper III CMB P3-A3 — wording lock

## Status

**P3_A3_WORDING_LOCK_DONE**

Safety: read-only on upstream CMB audit artefacts; writes only to `outputs/cmb_paperIII`; no ACT/Planck likelihood run; no NS touch.

## One-sentence locked claim

> The CMB does not kill MAP1782; it kills the vanilla late-density CMB dictionary and selects the strict face-minus Weyl-sector hierarchy, with primary-CMB, matter-growth, and Weyl/lensing responses kept distinct.

## Locked abstract paragraph

The CMB sector provides a dictionary-selection test for the MAP1782 branch. Across ACT DR6 lensing, Planck-lite high-ell/low-ell diagnostics, and Planck CMB-marginalized lensing, the naive vanilla late-density projection fails, while the strict face-minus hierarchy remains viable at diagnostic level. The ACT lenslike gate rejects the vanilla mapping with chi2_ACT=227.520768 versus 13.951140 for the Planck sanity point, whereas the strict Kprimary branch reaches chi2_ACT=14.153599 after scalar Weyl-auto profiling. The Planck-lite high-ell proxy similarly favours C_s_surv0 over the Planck sanity point by Delta chi2=-16.677397 and gives a catastrophic chi2=8851.940269 for the vanilla control. Finally, ACT and Planck lensing close with one common scalar Weyl-auto amplitude, amp_phi=1.057 (Sigma_eff=1.028105), with a joint penalty of only Delta chi2=0.825232 relative to separate minima. These results do not constitute a full official Planck nuisance-likelihood claim; they show that the CMB does not kill MAP1782, but kills the vanilla CMB dictionary and selects distinct primary-CMB, matter-growth, and Weyl/lensing responses.

## Wording rules

| id | object | locked_wording | allowed_strength | do_not_say |
|---|---|---|---|---|
| WR.ACT.01 | ACT DR6 lensing | ACT is treated with the full ACT DR6 lenslike diagnostic used by the pipeline. The strict face-minus/Kprimary branch is close to the ACT baseline after a small positive Weyl-auto amplitude profiling, whereas the vanilla late-density CMB dictionary is catastrophically disfavoured by the same diagnostic. | STRONG_DIAGNOSTIC | Do not call this a standalone full cosmological MCMC or a final combined CMB likelihood. |
| WR.PLANCKLITE.01 | Planck-lite TTTEEE high ell | The Planck-lite TTTEEE high-ell diagnostic is a controlled proxy/lite comparison, not the official full Planck nuisance-foreground likelihood. Within this proxy, the strict face-minus C_s_surv0 dictionary improves the profiled high-ell chi2 relative to the Planck sanity point, while the vanilla dictionary fails catastrophically. | STRONG_PROXY_WITH_EXPLICIT_LIMIT | Do not call it official full Planck, do not imply foreground/nuisance marginalization, and do not present it as a final Planck model-selection result. |
| WR.LOWELL.01 | Planck-lite high+low tau/As | The native lowT/lowE addition is a supporting consistency gate. It does not introduce a low-ell penalty against the strict branch at the audited point; the high+low tau/As grid remains favourable to C_s_surv0 relative to the Planck sanity point in this diagnostic setup. | SUPPORTING_DIAGNOSTIC | Do not overstate the low-ell module as a full Planck low-ell+nuisance production run. |
| WR.PLANCKLENS.01 | Planck CMB-marginalized lensing | Planck CMB-marginalized lensing is used as an official-formula lensing diagnostic with scalar amplitude profiling. The strict branch prefers a modest positive lensing/Weyl-auto amplitude and is not penalized relative to the Planck sanity point; the vanilla mapping is again the poor control. | CANONICAL_LENSING_DIAGNOSTIC | Do not call the three-band forensic scan the primary physical kernel fit. |
| WR.JOINTLENS.01 | ACT+Planck scalar lensing closure | The joint ACT+Planck lensing comparison is a scalar-amplitude closure diagnostic. A single positive Weyl-auto amplitude, amp_phi=1.057 (Sigma_eff=1.028105), jointly fits ACT and Planck lensing with only Delta chi2=0.825 relative to the sum of their separate minima. | SCALAR_CLOSURE_STRONG | Do not call it an official combined ACT+Planck likelihood, and do not infer a full window-dependent physical kernel from the scalar closure alone. |
| WR.CORECLAIM.01 | Paper III CMB core claim | The CMB branch does not kill MAP1782. It kills the vanilla late-density CMB dictionary and selects the strict face-minus Weyl-sector hierarchy: primary-CMB dictionary, matter growth response, and Weyl/lensing response must be kept distinct. | CORE_CLAIM | Do not weaken this into 'inconclusive'; the correct limit is that the claim is diagnostic/lite where appropriate, not null. |

## Claim wording

| claim_id | paper_wording | strength | source_gate |
|---|---|---|---|
| P3.ACT.01 | In the ACT DR6 lenslike diagnostic, the vanilla late-density projection is ruled out as a viable CMB dictionary: chi2_ACT=227.520768 versus 13.951140 for the Planck sanity point. The strict face-minus/Kprimary branch instead sits close to the ACT baseline, with chi2_ACT=17.470021 at unit amplitude and 14.153599 after scalar Weyl-auto profiling at amp_PhiPhi=1.043 (Sigma_eff=1.021274). | strong diagnostic | P3-A1/P3-A2 |
| P3.PLANCKLITE.01 | In the Planck-lite high-ell TTTEEE proxy, the strict C_s_surv0 dictionary gives best_full_chi2=749.191768, improving over the Planck_PR4 sanity point by Delta chi2=-16.677397, while the vanilla dictionary gives chi2=8851.940269 and is catastrophically excluded within the same proxy. | strong proxy, explicitly not official full Planck | P3-A1/P3-A2 |
| P3.PLANCKLOW.01 | Adding native lowT/lowE and profiling tau/As does not generate a compensating low-ell failure: C_s_surv0 gives total chi2=1164.645118 versus 1182.553918 for the Planck_PR4 sanity point, Delta chi2=-17.908799, with the lowT+lowE contribution slightly favourable by about -0.522. | supporting diagnostic | P3-A2 |
| P3.PLANCKLENS.01 | In the Planck CMB-marginalized lensing diagnostic, the strict branch is compatible with a modest positive Weyl-auto/lensing amplitude: best_amp_phi=1.075, Sigma_eff=1.036822, chi2=8.742460, compared with 9.181939 for the Planck sanity point and 20.544514 for the vanilla control. | canonical lensing diagnostic | P3-A1/P3-A2 |
| P3.JOINTLENS.01 | The ACT and Planck lensing amplitudes close with one common scalar parameter: the joint scalar best fit is amp_phi=1.057, Sigma_eff=1.028105, chi2_joint=23.721292. The penalty relative to the sum of the separate ACT-only and Planck-only minima is only Delta chi2=0.825232. | joint scalar-amplitude closure diagnostic | P3-A1b/P3-A2 |
| P3.CORE.01 | Across ACT lensing, Planck-lite high-ell/low-ell diagnostics, and CMB-marginalized lensing, the consistent lesson is not that BPB/MBE fails in the CMB. The failure mode is the naive vanilla dictionary. The strict face-minus branch remains viable at diagnostic level and selects a response hierarchy in which primary CMB, matter growth, and Weyl lensing are not collapsed into a single amplitude. | synthesis claim | P3-A3 |

## Table captions

| table_id | caption |
|---|---|
| T_CMB_ACT_DR6_lenslike | ACT DR6 lenslike diagnostic for the MAP1782 CMB dictionaries. The vanilla late-density mapping is shown as the failure control; the strict face-minus/Kprimary branch is close to the Planck sanity point and admits a small positive scalar Weyl-auto amplitude profile. |
| T_CMB_PlanckLite_high_ell | Planck-lite high-ell TTTEEE proxy comparison. This is not the official full Planck nuisance/foreground likelihood. It is used to test whether each CMB dictionary preserves the high-ell acoustic structure under the same lite/proxy assumptions. |
| T_CMB_PlanckLite_high_low_tau | Supporting high-ell plus native lowT/lowE tau/As grid. The low-ell modules are used as a consistency gate and do not introduce a compensating penalty against the strict face-minus branch at the audited point. |
| T_CMB_Planck_lensing_CMBmarged | Planck CMB-marginalized lensing official-formula diagnostic with scalar amplitude profiling. The strict branch prefers a modest positive lensing/Weyl-auto amplitude; the vanilla mapping remains the poor control. |
| T_CMB_Joint_ACT_Planck_scalar_lensing | Joint ACT+Planck scalar lensing closure. This is a scalar-amplitude diagnostic, not an official combined likelihood. The small penalty relative to separate ACT-only and Planck-only minima tests whether one common Weyl-auto response can serve both windows. |

## Figure captions

| figure_id | caption | must_show |
|---|---|---|
| Fig_P3_1_ACT_lensing_gate | ACT DR6 lenslike CMB dictionary gate. The vanilla late-density CMB mapping is catastrophically disfavoured, while the strict face-minus/Kprimary dictionary remains close to the Planck sanity point and improves under a small positive Weyl-auto amplitude profile. | Planck_PR4, A_vanilla_late_amp1, Kprimary_amp1, Kprimary scan best; annotate chi2_ACT values. |
| Fig_P3_2_PlanckLite_high_ell | Planck-lite high-ell TTTEEE proxy. The strict C_s_surv0 dictionary improves the profiled high-ell chi2 relative to the Planck sanity point in this lite diagnostic, while the vanilla dictionary fails by thousands in chi2. | Planck_PR4, C_s_surv0, optional C_Zbest, vanilla; visibly separate vanilla due to scale or broken axis/log inset. |
| Fig_P3_3_joint_lensing_scalar_closure | Scalar-amplitude closure for ACT DR6 and Planck CMB-marginalized lensing. ACT-only and Planck-only windows prefer nearby positive amplitudes, and one common amp_phi=1.057 gives a joint penalty of only Delta chi2=0.825 relative to separate minima. | ACT-only, Planck-only, joint scalar best; amp_phi, Sigma_eff, chi2_ACT, chi2_Planck_lensing, joint penalty. |
| Fig_P3_4_optional_proxy_contact_sheet | Optional proxy contact sheet collecting TT/TE/EE shape, peak-position, and lensing/Weyl proxy diagnostics. This figure is supporting only and should not replace the three canonical table-driven figures. | Only if needed in appendix/supplement; label clearly as proxy/diagnostic. |

## Forbidden / replacement phrases

| phrase | replacement |
|---|---|
| official full Planck likelihood | Planck-lite/proxy high-ell diagnostic, unless referring to a future required gate |
| full Planck nuisance marginalization | not performed here; future official pipeline gate |
| official combined ACT+Planck likelihood | joint scalar-amplitude diagnostic closure |
| Planck proves BPB | Planck-lite/lensing diagnostics do not kill the strict branch and reject the vanilla dictionary |
| inconclusive CMB result | diagnostic-level but strong dictionary-selection result |
| the Weyl response is the matter response | primary CMB, matter growth, and Weyl/lensing response are distinct |
| three-band kernel is the final physical kernel | three-band scan is supporting forensic/kernel diagnostic |

## Locked conclusion paragraph

The CMB result is therefore sharper than a generic consistency statement. The vanilla late-density dictionary is the failed branch. The strict face-minus dictionary is the surviving branch across the audited diagnostics. Because the lensing closure requires a modest positive Weyl-auto amplitude and because ACT, Planck-lite, and Planck lensing probe different windows, the paper should state the response hierarchy explicitly: the primary-CMB dictionary, the low-redshift matter response, and the Weyl/lensing response are not interchangeable amplitudes. The remaining caveat is procedural rather than conceptual: a future full official Planck nuisance/foreground MCMC and a physical Weyl-window kernel are required before claiming final CMB Bayesian model selection.

## Gate decisions

| decision | value |
|---|---|
| P3-A3 wording lock | PASS |
| ACT wording | LOCKED_FULL_LENSLIKE_DIAGNOSTIC |
| Planck-lite wording | LOCKED_PROXY_LITE_NOT_OFFICIAL_FULL_PLANCK |
| Planck lensing wording | LOCKED_OFFICIAL_FORMULA_CMBMARGED_DIAGNOSTIC |
| Joint lensing wording | LOCKED_SCALAR_AMPLITUDE_CLOSURE_NOT_OFFICIAL_COMBINED_LIKELIHOOD |
| Core claim | LOCKED_CMB_KILLS_VANILLA_NOT_STRICT_BRANCH |
| next_gate | P3-A4 figure generation |

## Open items

| id | item | status | note |
|---|---|---|---|
| P3A3.O01 | Generate publication-grade figures from locked table/figure captions | OPEN_NEXT | Recommended order: ACT gate, Planck-lite high-ell, joint scalar closure. |
| P3A3.O02 | Use P3-A1b joint patch as authoritative source if old source_tables summary still says joint_best=None | OPEN_LOW_RISK | Do not propagate the legacy extraction bug into paper tables. |
| P3A3.O03 | Future full official Planck nuisance/foreground MCMC | FUTURE_GATE_NOT_REQUIRED_FOR_CURRENT_WORDING | Explicit caveat retained; does not block Paper III diagnostic claim. |

## Outputs

- `outputs/cmb_paperIII/paperIII_cmb_p3a3_wording_lock.md`
- `outputs/cmb_paperIII/paperIII_cmb_p3a3_wording_lock.json`
- `outputs/cmb_paperIII/paperIII_cmb_p3a3_wording_rules.csv`
- `outputs/cmb_paperIII/paperIII_cmb_p3a3_claim_wording.csv`
- `outputs/cmb_paperIII/paperIII_cmb_p3a3_table_captions.csv`
- `outputs/cmb_paperIII/paperIII_cmb_p3a3_figure_captions.csv`
- `outputs/cmb_paperIII/paperIII_cmb_p3a3_forbidden_phrases.csv`
- `outputs/cmb_paperIII/paperIII_cmb_p3a3_open_items.csv`
