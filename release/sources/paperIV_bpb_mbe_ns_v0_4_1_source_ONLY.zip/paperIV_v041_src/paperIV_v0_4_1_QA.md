# Paper IV v0.4.1 QA / hotfix notes

Status: `HAL_READY_SOURCE_ONLY_HOTFIX`

## Applied fixes

- Added a bibliography directly in the LaTeX source using `thebibliography`.
- Added EOS references for APR, BSk24/BSk family support, TW/DD2, DDME2, NL3-family support, SFHo, and SLy4.
- Added tidal-deformability references: Hinderer 2008 and Hinderer et al. 2010.
- Added observational constraint references: two-solar-mass pulsars and GW170817.
- Fixed the broken figure file references in the NS-3 decomposition section:
  - `fig8_ns3_supported_decomposition_1p4`
  - `fig9_ns3_audit_summary`
- Added appendix labels for reproducibility, next targeted task, and release-index sections.
- Added a clearer physical sentence separating `beta_cl` from `beta_grow^{MAP1782}`.
- Updated source label from v0.4 to v0.4.1.

## Compile QA

Command used locally:

```bash
pdflatex -interaction=nonstopmode paperIV_bpb_mbe_ns_v0_4_1.tex
pdflatex -interaction=nonstopmode paperIV_bpb_mbe_ns_v0_4_1.tex
```

Result:

- LaTeX exit code: 0 after second pass.
- No unresolved `Table ??` / `Fig. ??` in the rendered PDF text.
- No missing figure files.
- No undefined citations reported after second pass.
- PDF was compiled for QA only and is not included in the source-only ZIP.

## Scientific changes

None. Numerical locks and claims are unchanged from v0.4.
