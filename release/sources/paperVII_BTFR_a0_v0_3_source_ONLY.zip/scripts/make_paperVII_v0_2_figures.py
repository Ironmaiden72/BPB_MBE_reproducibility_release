from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
FIG = ROOT / 'figs'
FIG.mkdir(exist_ok=True)

# Locked P7-A7 values
a0_bpb = 1.3678565925951916e-10
a0_mond = 1.2e-10

# Matplotlib defaults: clean, compact paper figures.
plt.rcParams.update({
    'font.size': 10,
    'axes.titlesize': 12,
    'axes.labelsize': 10,
    'legend.fontsize': 9,
    'figure.dpi': 160,
    'savefig.dpi': 220,
    'pdf.fonttype': 42,
    'ps.fonttype': 42,
})

# Figure 1: acceleration scale comparison
fig, ax = plt.subplots(figsize=(5.8, 3.5))
labels = ['MOND reference', 'BPB predicted']
vals = [a0_mond / 1e-10, a0_bpb / 1e-10]
colors = ['#8da0cb', '#66c2a5']
bars = ax.bar(labels, vals, color=colors, edgecolor='black', linewidth=0.8)
for b, v in zip(bars, vals):
    ax.text(b.get_x()+b.get_width()/2, v+0.035, f'{v:.3f}', ha='center', va='bottom')
ax.set_ylabel(r'$a_0$ [$10^{-10}$ m s$^{-2}$]')
ax.set_title('Absolute acceleration scale')
ax.set_ylim(0, 1.62)
ratio = a0_bpb/a0_mond
ax.text(0.5, 0.10, f'BPB/MOND = {ratio:.5f}\nshift = {(ratio-1)*100:+.2f}%',
        ha='center', va='bottom', transform=ax.transAxes,
        bbox=dict(boxstyle='round,pad=0.35', fc='white', ec='0.6'))
fig.tight_layout()
fig.savefig(FIG/'fig1_a0_scale_v02.pdf')
fig.savefig(FIG/'fig1_a0_scale_v02.png')
plt.close(fig)

# Figure 2: gate dashboard as horizontal matrix of status values
fig, ax = plt.subplots(figsize=(7.0, 3.2))
gates = ['A1\na0', 'A2D2\nthermal', 'A3\nBTFR', 'A4\nlikelihood', 'A5\nraw RC', 'A6/A6b\nprofile', 'A7\nlock']
levels = [1, 1, 1, 0.82, 0.78, 0.78, 1]
colors = ['#2ca25f', '#2ca25f', '#2ca25f', '#feb24c', '#feb24c', '#feb24c', '#2ca25f']
ax.barh([0]*len(gates), levels, left=np.arange(len(gates)), height=0.55, color=colors, edgecolor='black')
for i, g in enumerate(gates):
    ax.text(i+0.5, 0, g, ha='center', va='center', fontsize=9)
ax.set_xlim(0, len(gates))
ax.set_ylim(-0.6, 0.6)
ax.set_yticks([])
ax.set_xticks([])
ax.set_title('Paper VII v0.2 gate chain: fixed-a0 support with guardrails')
for i in range(1, len(gates)):
    ax.axvline(i, color='0.75', lw=0.7)
ax.text(3.5, -0.48, 'green = locked; amber = pass with explicit guardrail', ha='center', fontsize=9)
fig.tight_layout()
fig.savefig(FIG/'fig2_gate_dashboard_v02.pdf')
fig.savefig(FIG/'fig2_gate_dashboard_v02.png')
plt.close(fig)

# Figure 3: BTFR normalization residual summary
fig, ax = plt.subplots(figsize=(6.2, 3.8))
labels = ['Primary\nmedian', 'Primary\nRMS', 'Active38\nmedian', 'Active38\nRMS']
values = [-0.056007711329, 0.295494277101, -0.082524105026, 0.219939973556]
colors = ['#66c2a5', '#fc8d62', '#66c2a5', '#fc8d62']
bars = ax.bar(labels, values, color=colors, edgecolor='black', linewidth=0.8)
ax.axhline(0, color='black', lw=0.8)
for b, v in zip(bars, values):
    va = 'bottom' if v >= 0 else 'top'
    y = v + (0.015 if v >= 0 else -0.015)
    ax.text(b.get_x()+b.get_width()/2, y, f'{v:+.3f}', ha='center', va=va)
ax.set_ylabel('dex')
ax.set_title('Fixed-a0 BTFR normalization: residual diagnostics')
ax.set_ylim(-0.16, 0.36)
fig.tight_layout()
fig.savefig(FIG/'fig3_btfr_residuals_v02.pdf')
fig.savefig(FIG/'fig3_btfr_residuals_v02.png')
plt.close(fig)

# Figure 4: A4 likelihood BIC comparison
fig, ax = plt.subplots(figsize=(6.2, 3.8))
models = ['BPB fixed\nslope 4', 'free offset\nslope 4', 'free slope']
bic = [0.0, 1.63621196439, -25.41666641103]
colors = ['#66c2a5', '#8da0cb', '#fc8d62']
bars = ax.bar(models, bic, color=colors, edgecolor='black', linewidth=0.8)
ax.axhline(0, color='black', lw=0.8)
for b, v in zip(bars, bic):
    ax.text(b.get_x()+b.get_width()/2, v + (0.9 if v >= 0 else -1.1), f'{v:+.2f}', ha='center', va='bottom' if v >=0 else 'top')
ax.set_ylabel(r'$\Delta$BIC vs fixed BPB')
ax.set_title('Minimal BTFR likelihood: normalization passes, slope guardrail remains')
ax.set_ylim(-30, 8)
fig.tight_layout()
fig.savefig(FIG/'fig4_btfr_likelihood_bic_v02.pdf')
fig.savefig(FIG/'fig4_btfr_likelihood_bic_v02.png')
plt.close(fig)

# Figure 5: raw RC chi2 improvement
fig, ax = plt.subplots(figsize=(6.2, 3.8))
labels = ['Baryon-only\nNewtonian', 'Fixed-a0\nRAR']
chi2 = [1751618.840117, 155530.570678]
bars = ax.bar(labels, np.array(chi2)/1e6, color=['#e5c494', '#66c2a5'], edgecolor='black', linewidth=0.8)
for b, v in zip(bars, chi2):
    ax.text(b.get_x()+b.get_width()/2, v/1e6+0.03, f'{v/1e6:.3f}', ha='center')
ax.set_ylabel(r'raw $\chi^2$ [$10^6$]')
ax.set_title('Point-level SPARC baryonic RC gate')
ax.text(0.5, 0.70, 'fractional improvement = 0.9112', transform=ax.transAxes, ha='center',
        bbox=dict(boxstyle='round,pad=0.3', fc='white', ec='0.6'))
fig.tight_layout()
fig.savefig(FIG/'fig5_raw_rc_improvement_v02.pdf')
fig.savefig(FIG/'fig5_raw_rc_improvement_v02.png')
plt.close(fig)

# Figure 6: a0 profile ratios
fig, ax = plt.subplots(figsize=(7.0, 3.8))
labels = ['Fixed\nBPB', 'A5 global\nbest RAR', 'A6b primary\nprofile', 'A6b active38\nshape check']
ratios = [1.0, 0.891250938134, 0.807075252405, 0.486722101981]
colors = ['#2ca25f', '#66c2a5', '#feb24c', '#fc8d62']
bars = ax.bar(labels, ratios, color=colors, edgecolor='black', linewidth=0.8)
ax.axhline(1.0, color='0.2', lw=0.8, ls='--')
for b, v in zip(bars, ratios):
    ax.text(b.get_x()+b.get_width()/2, v+0.025, f'{v:.3f}', ha='center')
ax.set_ylabel(r'$a_0/a_0^{\rm BPB}$')
ax.set_title('Global nuisance/profile diagnostics for the acceleration anchor')
ax.set_ylim(0, 1.15)
fig.tight_layout()
fig.savefig(FIG/'fig6_a0_profile_ratios_v02.pdf')
fig.savefig(FIG/'fig6_a0_profile_ratios_v02.png')
plt.close(fig)

print('Figures written to', FIG)
