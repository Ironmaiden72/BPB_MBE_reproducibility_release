# Paper III CMB A0 — status audit without touching NS

## Status

**CMB PAPER III STATUS AUDIT DONE — non-destructive.**

This gate scans CMB/ACT/Planck-related artefacts while explicitly avoiding NS paths. It does not run a likelihood, does not patch source files, and does not touch `outputs/ns`.

## Scan summary

| quantity | value |
|---|---:|
| relevant files | 668 |
| JSON key/value hits | 32035 |
| CSV summaries | 199 |

## Claim seed table

| id | status | claim | numbers | paper use |
|---|---|---|---|---|
| P3.CLAIM.ACT.01 | CONTEXT_LOCKED_NEEDS_FILE_SOURCE_MATCH | Direct ACT DR6 lenslike is operational through load_data + generic_lnlike. | Planck_PR4_amp1 chi2≈13.951; Kprimary chi2≈17.470; Kprimary_CMB8_amp chi2≈14.156; vanilla late-density chi2≈227.521. | Show ACT is a Weyl/stress gate, not a crash for strict face-minus BPB. |
| P3.CLAIM.PLANCKLITE.01 | CONTEXT_LOCKED_NEEDS_FILE_SOURCE_MATCH | Planck-lite TTTEEE proxy does not show a shape crash for strict face-minus, while vanilla mapping is catastrophic. | Planck sanity chi2≈794.70; vanilla≈8704.88; strict C_s_surv0≈835.54 at ns=0.9649. | Main high-ell CMB safety claim. |
| P3.CLAIM.PLANCKLITE.02 | CONTEXT_LOCKED_NEEDS_FILE_SOURCE_MATCH | Fine ns scan leaves strict face-minus with a residual penalty mostly from A_planck/amplitude prior. | Best Planck ns≈0.970 chi2≈791.31; best strict ns≈0.976 chi2≈817.79; residual Δχ²≈+26.48; Δprior≈+31.53 and Δdata≈-5.05. | Explains why penalty is amplitude calibration, not TT/TE/EE residual shape. |
| P3.CLAIM.JOINTLENS.01 | CONTEXT_LOCKED_NEEDS_FILE_SOURCE_MATCH | A common positive scalar Weyl-auto/lensing amplitude closes joint ACT+Planck-lensing at diagnostic level. | Joint best amp_phi≈1.057, Sigma≈1.028105, chi2_ACT≈14.478027, chi2_Planck≈9.243264, joint≈23.721292; separate-min sum≈22.896060; penalty≈0.825232. | Joint ACT+Planck lensing closure diagnostic. |

## Most relevant files found

| path | suffix | size bytes |
|---|---|---:|
| `data_oracle/ns_branch/results/GR_compact_at_Mth.npy` | `.npy` | 407 |
| `data_oracle/sparc_audit/data/sparc_active_sample.csv` | `.csv` | 4451 |
| `data_oracle/sparc_audit/results/ttest_active_inactive.csv` | `.csv` | 263 |
| `outputs/benchmarks/benchmark_genesis_raw_bestfit_actfull.json` | `.json` | 862 |
| `outputs/cmb/act_lenslike_api_probe.stdout.txt` | `.txt` | 126214 |
| `outputs/cmb/act_lenslike_api_probe.txt` | `.txt` | 126166 |
| `outputs/cmb/cmb10b_act_unified_dryrun_spec_map1782.json` | `.json` | 8019 |
| `outputs/cmb/cmb10b_act_unified_dryrun_spec_map1782.md` | `.md` | 6474 |
| `outputs/cmb/cmb10b_act_unified_lenslike_map1782.csv` | `.csv` | 19944 |
| `outputs/cmb/cmb10b_act_unified_lenslike_map1782.json` | `.json` | 52030 |
| `outputs/cmb/cmb10b_act_unified_lenslike_map1782.md` | `.md` | 2413 |
| `outputs/cmb/cmb10b_act_unified_lenslike_map1782.scan.csv` | `.csv` | 11219 |
| `outputs/cmb/cmb10b_act_unified_lenslike_map1782.theory_vectors.npz` | `.npz` | 1471 |
| `outputs/cmb/cmb10b_act_unified_lenslike_map1782_refined.csv` | `.csv` | 25040 |
| `outputs/cmb/cmb10b_act_unified_lenslike_map1782_refined.json` | `.json` | 64187 |
| `outputs/cmb/cmb10b_act_unified_lenslike_map1782_refined.md` | `.md` | 2413 |
| `outputs/cmb/cmb10b_act_unified_lenslike_map1782_refined.scan.csv` | `.csv` | 14084 |
| `outputs/cmb/cmb10b_act_unified_lenslike_map1782_refined.theory_vectors.npz` | `.npz` | 1471 |
| `outputs/cmb/cmb11a_planck_likelihood_availability.json` | `.json` | 120494 |
| `outputs/cmb/cmb11a_planck_likelihood_availability.md` | `.md` | 59833 |
| `outputs/cmb/cmb11b_clik_planck_smoke.json` | `.json` | 2242 |
| `outputs/cmb/cmb11b_clik_planck_smoke.md` | `.md` | 1401 |
| `outputs/cmb/cmb11c_planck_lite_ttteee_map1782.json` | `.json` | 2089 |
| `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9700.json` | `.json` | 2086 |
| `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9700.log` | `.log` | 2863 |
| `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9720.json` | `.json` | 2087 |
| `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9720.log` | `.log` | 2863 |
| `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9740.json` | `.json` | 2086 |
| `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9740.log` | `.log` | 2863 |
| `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9760.json` | `.json` | 2091 |
| `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9760.log` | `.log` | 2875 |
| `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9780.json` | `.json` | 2091 |
| `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9780.log` | `.log` | 2875 |
| `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9800.json` | `.json` | 2093 |
| `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9800.log` | `.log` | 2875 |
| `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9820.json` | `.json` | 2089 |
| `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9820.log` | `.log` | 2875 |
| `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9840.json` | `.json` | 2088 |
| `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9840.log` | `.log` | 2873 |
| `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9860.json` | `.json` | 2089 |
| `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9860.log` | `.log` | 2873 |
| `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9880.json` | `.json` | 2092 |
| `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9880.log` | `.log` | 2873 |
| `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9900.json` | `.json` | 2093 |
| `outputs/cmb/cmb11d_ns_fine_scan/planck_lite_ns_0p9900.log` | `.log` | 2873 |
| `outputs/cmb/cmb11d_ns_scan/planck_lite_ns_0p9500.json` | `.json` | 2087 |
| `outputs/cmb/cmb11d_ns_scan/planck_lite_ns_0p9500.log` | `.log` | 2858 |
| `outputs/cmb/cmb11d_ns_scan/planck_lite_ns_0p9550.json` | `.json` | 2085 |
| `outputs/cmb/cmb11d_ns_scan/planck_lite_ns_0p9550.log` | `.log` | 2858 |
| `outputs/cmb/cmb11d_ns_scan/planck_lite_ns_0p9600.json` | `.json` | 2088 |
| `outputs/cmb/cmb11d_ns_scan/planck_lite_ns_0p9600.log` | `.log` | 2858 |
| `outputs/cmb/cmb11d_ns_scan/planck_lite_ns_0p9649.json` | `.json` | 2089 |
| `outputs/cmb/cmb11d_ns_scan/planck_lite_ns_0p9649.log` | `.log` | 2858 |
| `outputs/cmb/cmb11d_ns_scan/planck_lite_ns_0p9700.json` | `.json` | 2086 |
| `outputs/cmb/cmb11d_ns_scan/planck_lite_ns_0p9700.log` | `.log` | 2858 |
| `outputs/cmb/cmb11d_ns_scan/planck_lite_ns_0p9750.json` | `.json` | 2085 |
| `outputs/cmb/cmb11d_ns_scan/planck_lite_ns_0p9750.log` | `.log` | 2870 |
| `outputs/cmb/cmb11d_ns_scan/planck_lite_ns_0p9800.json` | `.json` | 2093 |
| `outputs/cmb/cmb11d_ns_scan/planck_lite_ns_0p9800.log` | `.log` | 2870 |
| `outputs/cmb/cmb11e_planck_lite_block_forensic_map1782.json` | `.json` | 14955 |
| `outputs/cmb/cmb11f_As_scan/planck_lite_AsScale_0p940.json` | `.json` | 2089 |
| `outputs/cmb/cmb11f_As_scan/planck_lite_AsScale_0p940.log` | `.log` | 2864 |
| `outputs/cmb/cmb11f_As_scan/planck_lite_AsScale_0p950.json` | `.json` | 2093 |
| `outputs/cmb/cmb11f_As_scan/planck_lite_AsScale_0p950.log` | `.log` | 2873 |
| `outputs/cmb/cmb11f_As_scan/planck_lite_AsScale_0p960.json` | `.json` | 2093 |
| `outputs/cmb/cmb11f_As_scan/planck_lite_AsScale_0p960.log` | `.log` | 2873 |
| `outputs/cmb/cmb11f_As_scan/planck_lite_AsScale_0p970.json` | `.json` | 2092 |
| `outputs/cmb/cmb11f_As_scan/planck_lite_AsScale_0p970.log` | `.log` | 2873 |
| `outputs/cmb/cmb11f_As_scan/planck_lite_AsScale_0p980.json` | `.json` | 2092 |
| `outputs/cmb/cmb11f_As_scan/planck_lite_AsScale_0p980.log` | `.log` | 2873 |
| `outputs/cmb/cmb11f_As_scan/planck_lite_AsScale_0p990.json` | `.json` | 2091 |
| `outputs/cmb/cmb11f_As_scan/planck_lite_AsScale_0p990.log` | `.log` | 2872 |
| `outputs/cmb/cmb11f_As_scan/planck_lite_AsScale_1p000.json` | `.json` | 2091 |
| `outputs/cmb/cmb11f_As_scan/planck_lite_AsScale_1p000.log` | `.log` | 2874 |
| `outputs/cmb/cmb11f_As_scan/planck_lite_AsScale_1p010.json` | `.json` | 2087 |
| `outputs/cmb/cmb11f_As_scan/planck_lite_AsScale_1p010.log` | `.log` | 2862 |
| `outputs/cmb/cmb11f_As_scan/planck_lite_AsScale_1p020.json` | `.json` | 2089 |
| `outputs/cmb/cmb11f_As_scan/planck_lite_AsScale_1p020.log` | `.log` | 2864 |
| `outputs/cmb/cmb11f_As_scan/planck_lite_AsScale_1p030.json` | `.json` | 2090 |
| `outputs/cmb/cmb11f_As_scan/planck_lite_AsScale_1p030.log` | `.log` | 2867 |
| ... | ... | 588 more |

## CSV summaries with chi2 hints

| file | status | rows | cols | chi2 min | best row hint |
|---|---|---:|---:|---:|---|
| `data_oracle/sparc_audit/data/sparc_active_sample.csv` | OK | 38 | 13 | -1800.37 | `{"name": "IC2574", "dchi2_physical": "-1800.37"}` |
| `data_oracle/sparc_audit/results/ttest_active_inactive.csv` | OK | 6 | 5 | None | `` |
| `outputs/cmb/cmb10b_act_unified_lenslike_map1782.csv` | OK | 86 | 12 | 13.951140258982589 | `{"case": "Planck_PR4_amp1", "kind": "special", "chi2_ACT": "13.951140258982589"}` |
| `outputs/cmb/cmb10b_act_unified_lenslike_map1782.scan.csv` | OK | 81 | 7 | 14.21486704595536 | `{"case": "Kprimary_scan", "kind": "scan", "chi2_ACT": "14.21486704595536"}` |
| `outputs/cmb/cmb10b_act_unified_lenslike_map1782_refined.csv` | OK | 106 | 12 | 13.951140258982589 | `{"case": "Planck_PR4_amp1", "kind": "special", "chi2_ACT": "13.951140258982589"}` |
| `outputs/cmb/cmb10b_act_unified_lenslike_map1782_refined.scan.csv` | OK | 101 | 7 | 14.15359945719008 | `{"case": "Kprimary_scan", "kind": "scan", "chi2_ACT": "14.15359945719008"}` |
| `outputs/cmb/cmb11g_planck_lite_ns_As_grid_map1782.best.csv` | OK | 3 | 18 | 749.191767798833 | `{"case": "C_s_surv0", "best_full_chi2": "749.191767798833"}` |
| `outputs/cmb/cmb11g_planck_lite_ns_As_grid_map1782.csv` | OK | 231 | 14 | 749.191767798833 | `{"case": "C_s_surv0", "chi2_full": "749.191767798833"}` |
| `outputs/cmb/cmb11g_planck_lite_ns_As_grid_map1782_with_vanilla.best.csv` | OK | 4 | 18 | 749.191767798833 | `{"case": "C_s_surv0", "best_full_chi2": "749.191767798833"}` |
| `outputs/cmb/cmb11g_planck_lite_ns_As_grid_map1782_with_vanilla.csv` | OK | 308 | 14 | 749.191767798833 | `{"case": "C_s_surv0", "chi2_full": "749.191767798833"}` |
| `outputs/cmb/cmb11h_planck_lite_ns_As_grid_extended_map1782.best.csv` | OK | 3 | 18 | 749.191767798833 | `{"case": "C_s_surv0", "best_full_chi2": "749.191767798833"}` |
| `outputs/cmb/cmb11h_planck_lite_ns_As_grid_extended_map1782.csv` | OK | 396 | 14 | 749.191767798833 | `{"case": "C_s_surv0", "chi2_full": "749.191767798833"}` |
| `outputs/cmb/cmb12e_highl_lowl_tau_As_grid_map1782.best.csv` | OK | 2 | 23 | 1164.6451180840354 | `{"case": "C_s_surv0", "best_total_chi2": "1164.6451180840354"}` |
| `outputs/cmb/cmb12e_highl_lowl_tau_As_grid_map1782.csv` | OK | 80 | 22 | 747.3058232158619 | `{"case": "C_s_surv0", "highl_chi2": "747.3058232158619"}` |
| `outputs/cmb/cmb12f_highl_lowl_tau_As_grid_extended_map1782.best.csv` | OK | 2 | 23 | 1164.6451180840354 | `{"case": "C_s_surv0", "best_total_chi2": "1164.6451180840354"}` |
| `outputs/cmb/cmb12f_highl_lowl_tau_As_grid_extended_map1782.csv` | OK | 90 | 22 | 744.3789843141037 | `{"case": "C_s_surv0", "highl_chi2": "744.3789843141037"}` |
| `outputs/cmb/cmb13d_planck_lensing_official_formula_map1782.csv` | OK | 3 | 20 | 9.84995395112301 | `{"case": "Planck_PR4_12F", "chi2_amp1": "9.84995395112301"}` |
| `outputs/cmb/cmb14a_planck_lensing_bin_forensic_map1782.csv` | OK | 63 | 16 | 6.81359681245105e-05 | `{"case": "BPB_vanilla", "amp_phi": "0.8400000000000001", "Sigma_eff": "0.916515138991168", "white_component_chi2": "6.81359681245105e-05"}` |
| `outputs/cmb/cmb14a_planck_lensing_bin_forensic_map1782.summary.csv` | OK | 7 | 10 | 8.742460151124908 | `{"case": "BPB_C_s_surv0", "amp_phi": "1.0750000000000002", "Sigma_eff": "1.0368220676663862", "chi2": "8.742460151124908"}` |
| `outputs/cmb/cmb14b_planck_lensing_kernel_models_map1782.bins.csv` | OK | 135 | 14 | 0.0014176744287766 | `{"case": "BPB_C_s_surv0", "white_component_chi2": "0.0014176744287766"}` |
| `outputs/cmb/cmb14b_planck_lensing_kernel_models_map1782.summary.csv` | OK | 15 | 20 | 2.235354820530869 | `{"case": "BPB_C_s_surv0", "chi2": "2.235354820530869"}` |
| `outputs/cmb/cmb15a_joint_act_planck_scalar_amp_map1782.grid.csv` | OK | 2001 | 5 | 13.951140258982589 | `{"amp_phi": "1.0", "Sigma_eff": "1.0", "chi2_ACT": "13.951140258982589"}` |
| `outputs/cmb/cmb15a_joint_act_planck_scalar_amp_map1782.refs.csv` | OK | 7 | 9 | 13.951140258982589 | `{"label": "ACT_best", "amp_phi": "1.0", "Sigma_eff": "1.0", "chi2_ACT": "13.951140258982589"}` |
| `outputs/cmb/cmb15a_v2_joint_act_planck_scalar_amp_map1782.grid.csv` | OK | 4001 | 5 | 13.951140258982589 | `{"amp_phi": "1.0", "Sigma_eff": "1.0", "chi2_ACT": "13.951140258982589"}` |
| `outputs/cmb/cmb15a_v2_joint_act_planck_scalar_amp_map1782.refs.csv` | OK | 6 | 9 | 13.951140258982589 | `{"label": "ACT_best", "amp_phi": "1.0", "Sigma_eff": "1.0", "chi2_ACT": "13.951140258982589"}` |
| `outputs/cmb/cmb15a_v4_joint_act_planck_scalar_amp_map1782.grid.csv` | OK | 4001 | 5 | 14.15359945719008 | `{"amp_phi": "1.043", "Sigma_eff": "1.0212737145349429", "chi2_ACT": "14.15359945719008"}` |
| `outputs/cmb/cmb15a_v4_joint_act_planck_scalar_amp_map1782.refs.csv` | OK | 5 | 9 | 14.15359945719008 | `{"label": "ACT_best", "amp_phi": "1.043", "Sigma_eff": "1.0212737145349429", "chi2_ACT": "14.15359945719008"}` |
| `outputs/cmb/cmb_lensing_weyl_proxy_map1782.binned.csv` | OK | 55 | 14 | None | `` |
| `outputs/cmb/cmb_lensing_weyl_proxy_map1782.derived.csv` | OK | 4 | 13 | None | `` |
| `outputs/cmb/cmb_lensing_weyl_proxy_map1782.summary.csv` | OK | 15 | 16 | 0.0 | `{"case": "A_vanilla_late", "proxy_chi2_per_point_5pct": "0.0"}` |
| `outputs/cmb/cmb_lensing_weyl_proxy_map1782_A_vanilla_late_raw.csv` | OK | 2201 | 2 | None | `` |
| `outputs/cmb/cmb_lensing_weyl_proxy_map1782_C_Zbest_theta_raw.csv` | OK | 2201 | 2 | None | `` |
| `outputs/cmb/cmb_lensing_weyl_proxy_map1782_C_s_surv0_raw.csv` | OK | 2201 | 2 | None | `` |
| `outputs/cmb/cmb_lensing_weyl_proxy_map1782_Planck_PR4_raw.csv` | OK | 2201 | 2 | None | `` |
| `outputs/cmb/cmb_peak_proxy_budget_map1782.compare.csv` | OK | 4 | 34 | None | `` |
| `outputs/cmb/cmb_peak_proxy_budget_map1782.derived.csv` | OK | 4 | 7 | None | `` |
| `outputs/cmb/cmb_peak_proxy_budget_map1782.peaks.csv` | OK | 4 | 18 | None | `` |
| `outputs/cmb/cmb_peak_proxy_budget_map1782_A_vanilla_late_spectrum.csv` | OK | 2251 | 3 | None | `` |
| `outputs/cmb/cmb_peak_proxy_budget_map1782_C_Zbest_theta_spectrum.csv` | OK | 2251 | 3 | None | `` |
| `outputs/cmb/cmb_peak_proxy_budget_map1782_C_s_surv0_spectrum.csv` | OK | 2251 | 3 | None | `` |
| `outputs/cmb/cmb_peak_proxy_budget_map1782_Planck_PR4_spectrum.csv` | OK | 2251 | 3 | None | `` |
| `outputs/cmb/cmb_polarization_proxy_map1782.binned.csv` | OK | 55 | 16 | None | `` |
| `outputs/cmb/cmb_polarization_proxy_map1782.derived.csv` | OK | 4 | 12 | None | `` |
| `outputs/cmb/cmb_polarization_proxy_map1782.summary.csv` | OK | 36 | 18 | 0.0141798530415684 | `{"case": "C_s_surv0", "proxy_chi2_per_point_1pct": "0.0141798530415684"}` |
| `outputs/cmb/cmb_pre_recombination_budget_map1782.csv` | OK | 4 | 28 | None | `` |
| `outputs/cmb/cmb_tt_shape_proxy_map1782.binned.csv` | OK | 165 | 11 | None | `` |
| `outputs/cmb/cmb_tt_shape_proxy_map1782.summary.csv` | OK | 12 | 28 | 0.037358645017791 | `{"case": "C_s_surv0", "raw_proxy_chi2_per_point_1pct": "0.037358645017791"}` |
| `outputs/cmb/cmb_zcold_scan_benchmark.csv` | OK | 31 | 14 | None | `` |
| `outputs/cmb/cmb_zcold_scan_map1782.csv` | OK | 31 | 14 | None | `` |
| `outputs/cosmology/act_eg_autocross_joint_summary_seed01.csv` | OK | 3 | 12 | 22.9271 | `{"lcdm_act_chi2": "22.9271"}` |
| `outputs/cosmology/act_eg_physical_autocross_summary_seed01.csv` | OK | 6 | 14 | None | `` |
| `outputs/cosmology/act_sigma_kwindow_diagnostic_seed01.csv` | OK | 51 | 11 | 19.12258689889689 | `{"label": "constant_ACT_c_high", "chi2_ACT": "19.12258689889689"}` |
| `outputs/cosmology/act_sigma_power_diagnostic_seed01.csv` | OK | 5 | 7 | 19.12258689889689 | `{"label": "ACT_closure_quadratic_power2", "chi2_act": "19.12258689889689"}` |
| `outputs/cosmology/autocross_delta_phi_toy_local_sensitivity_frozen_point.csv` | OK | 125 | 8 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_frozen_point.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O10p0_G1p0.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O10p0_G1p5.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O10p0_G2p0.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O10p0_G2p5.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O10p0_G3p0.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O12p0_G1p0.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O12p0_G1p5.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O12p0_G2p0.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O12p0_G2p5.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O12p0_G3p0.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O4p0_G1p0.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O4p0_G1p5.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O4p0_G2p0.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O4p0_G2p5.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O4p0_G3p0.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O6p0_G1p0.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O6p0_G1p5.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O6p0_G2p0.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O6p0_G2p5.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O6p0_G3p0.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O8p0_G1p0.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O8p0_G1p5.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O8p0_G2p0.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O8p0_G2p5.csv` | OK | 13 | 15 | None | `` |
| `outputs/cosmology/autocross_delta_phi_toy_projector_tmp_D0p015_O8p0_G3p0.csv` | OK | 13 | 15 | None | `` |
| ... | ... |  |  |  | 119 more |

## Open items

| id | item | reason | next action |
|---|---|---|---|
| P3.OPEN.01 | source-file matching | Audit script may find outputs, but claims must be tied to exact JSON/CSV rows before paper lock. | Inspect generated relevant_files/json_key_values/csv_summaries and point each claim to a file. |
| P3.OPEN.02 | figure plan | Paper III likely needs a compact figure set: ACT comparison, Planck-lite residual/pull, joint amp_phi closure. | After source matching, build or locate figures. |
| P3.OPEN.03 | claim level | Some CMB outputs are diagnostic/proxy, not full official Planck likelihood. | Separate 'full likelihood' ACT from 'Planck-lite/proxy' wording. |
| P3.OPEN.04 | NS isolation | NS full run is active. | Do not touch outputs/ns, src/ns, or NS checkpoints during CMB work. |

## Gate decision

| item | decision |
|---|---|
| CMB audit | PASS |
| NS touched | NO |
| likelihood run | NO |
| paper claims locked | NOT_YET_SOURCE_MATCH_REQUIRED |
| next gate | P3-A1 source-match claims to exact files |

## Recommended next gate

```text
P3-A1 : map each CMB claim to exact JSON/CSV artefacts and decide paper wording level.
```
