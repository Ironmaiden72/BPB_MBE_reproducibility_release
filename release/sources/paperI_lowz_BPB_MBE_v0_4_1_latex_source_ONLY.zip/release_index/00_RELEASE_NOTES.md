# BPB/MBE release stage-1 notes — 2026-05-05

## Package basis

- Uploaded core ZIP: `BPB_MBE_release_core_20260505.zip`
- ZIP sha256: `9671569653cd2fbb1e069213a10d624ecdd958e5a445eabfb183b846954507c8`
- Extracted file count used for this stage: `2463`
- Stage-1 purpose: freeze the release map before editing manuscripts.

## Stage-1 files generated

- `00_MANIFEST_CORPUS.csv` — release manifest, one row per corpus/paper layer.
- `00_CLAIMS_INDEX.csv` — normalized claim/source-lock index, `72` rows.
- `00_REVIEWER_ROUTE.md` and `00_REVIEWER_ROUTE.csv` — quick audit route.
- `00_RELEASE_TODO.csv` — missing files/actions before HAL/arXiv-style release.

## Current corpus status

| layer | status |
|---|---|
| 00_README_CORPUS | READY_V0_2_OUTSIDE_REPO_ZIP |
| 00_MANIFEST_CORPUS | READY_STAGE1 |
| 00_CLAIMS_INDEX | READY_STAGE1 |
| Paper_0 | SOURCE_PRESENT_COMPILED_CURRENT_ZIP_NEEDS_CORPUS_AWARE_FINAL |
| Paper_I | LEGACY_PAPERI_V2_PRESENT_NEEDS_FROZEN_V0_3_SYNC |
| Paper_II | D3_D5_D6_D7_LOCKS_PRESENT_MANUSCRIPT_MISSING |
| Paper_III | P3_CMB_AUDIT_CLOSED_PRE_LATEX_MANUSCRIPT_MISSING |
| Paper_IV | NS_STRICT_GLOBAL_AND_1P4_SOURCE_LOCKS_PRESENT_MANUSCRIPT_MISSING |
| Paper_V | NOT_FOUND_IN_UPLOADED_CORE_ZIP |
| Paper_VI | EG_T_SERIES_LOCKS_PRESENT_MANUSCRIPT_MISSING |
| Paper_VII | P7_A1_TO_A7_LOCKED_MANUSCRIPT_PDF_OUTSIDE_ZIP |


## Claims indexed by paper

| paper | indexed rows |
|---|---:|
| Paper_0 | 1 |
| Paper_II | 23 |
| Paper_III | 6 |
| Paper_IV | 4 |
| Paper_VII | 38 |


## Release guardrails to keep visible

1. Paper 0 is the dictionary/foundation; it does not by itself prove every observational descendant.
2. Paper I must be synced to the frozen v0.3 low-z lock before final release.
3. Paper II D5/D6 is a raw-RC validated source-only kernel recovering most of the clean-to-archive amplitude gap; it is not exact archive/oracle recovery.
4. Paper III/D7 CAMB and CMB locks are diagnostic/mechanism gates unless a full official Planck likelihood is explicitly locked.
5. Paper IV neutron-star results are strict effective tidal-response locks; native scalar-tensor Love-number closure remains a separate gate.
6. Paper VI E_G/Weyl closure is projected/conditional unless the action-level projector is separately derived.
7. Paper VII is fixed-a0 BTFR/interpolation support, not full SPARC RC likelihood or unique MOND interpolation derivation.

## Immediate next action

Proceed to Paper 0 corpus-aware update only after copying/staging the `00_*` files into the repo root, because Paper 0 should point to the final manifest and claims index.
