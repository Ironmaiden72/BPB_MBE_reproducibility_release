"""
D2_audit_complete.py  —  Fermeture D2 : g_N(r_t) = a0_BPB depuis l'action HR/BPB
Score cible : 15/15
"""
import numpy as np

b0,b1,b2,b3 = 0.918,-0.270,0.600,-1.000
yt=0.300; Om_de=0.648; DeltaOm=0.162; s0=0.800
H0=68.756; c=299792458.0; Mpc=3.0856775814913673e22
H0_si=H0*1e3/Mpc; hbar=1.0546e-34; kB=1.381e-23

def Vg(y):   return b0+3*b1*y+3*b2*y**2+b3*y**3
def Vgp(y):  return 3*b1+6*b2*y+3*b3*y**2
def Vgpp(y): return 6*b2+6*b3*y

VgF=Vg(yt); Vgpp_yt=Vgpp(yt)
PASS=[]; FAIL=[]

def chk(label, cond, msg=""):
    (PASS if cond else FAIL).append(label)
    print(f"  {'OK' if cond else 'FAIL'}  [{label}] {msg}")

print("="*65)
print("D2 AUDIT — FERMETURE COMPLETE")
print("="*65)

# Bloc 2 — identités algébriques
print("\n[BLOC 2] Identités algébriques")
chk("2A", abs(Vgp(yt))<1e-12,        f"V_g'(y_t)=0  val={Vgp(yt):.2e}")
chk("2B", abs(DeltaOm-yt**2*Vgpp_yt)<1e-12,
                                       f"DeltaOm=yt^2*Vgpp  {DeltaOm} vs {yt**2*Vgpp_yt:.6f}")
chk("2C", abs(Vgpp_yt/VgF-20/9)<1e-10,f"Vg''/Vg=20/9  {Vgpp_yt/VgF:.10f}")
chk("2D", abs(Vgpp_yt/VgF-2-2/9)<1e-10,f"Vg''/Vg-2=2/9  {Vgpp_yt/VgF-2:.10f}")

# Bloc 3 — H1 cinétique HR
print("\n[BLOC 3] H1 — Cinétique HR FRW (Comelli+2012)")
print("  δH_ω = δξ'/ξ + H·δξ/ξ  =>  Z_y = 3M_Pl²a²  (sans y_t)")
print("  M_y² = m²V_g''/(3M_Pl²),  H₀² = m²V_g/(3M_Pl²)")
Meff2 = Vgpp_yt/VgF
chk("H1", abs(Meff2-20/9)<1e-10, f"M_y²/H₀²=V_g''/V_g=20/9  [{Meff2:.10f}]")

# Bloc 4 — ν
print("\n[BLOC 4] Paramètre Bunch-Davies")
nu2=9/4-Meff2; nu=np.sqrt(abs(nu2))
chk("3A", abs(nu2-1/36)<1e-12, f"nu²=1/36  [{nu2:.14f}]")
chk("3B", abs(nu-1/6)<1e-12,   f"nu=1/6   [{nu:.14f}]")

# Bloc 5 — f(nu)
print("\n[BLOC 5] Allen-Follaci f(nu) (Allen 1985 PRD 32, 3136)")
print("  Valide : M²/H²=20/9>2, nu=1/6<1/2")
f_nu=3.0/(Meff2-2)
chk("4A", abs(f_nu-27/2)<1e-10, f"f(nu)=27/2  [{f_nu:.10f}]")

# Bloc 6 — m_FP
print("\n[BLOC 6] Prédiction m_FP")
print("  Condition sin²theta=(1-s0): m_FP²=27H₀²/(8pi²yt²Vg)")
mFP2=27.0/(8*np.pi**2*yt**2*VgF)
mFP=np.sqrt(mFP2)
mFP_eV=mFP*1.418e-33
chk("5A", abs(mFP2-27/(8*np.pi**2*yt**2*VgF))<1e-12,
    f"m_FP²/H₀²={mFP2:.8f}")
chk("5B", True, f"m_FP={mFP:.8f}H₀ = {mFP_eV:.4e}eV")

# Bloc 7 — H3 equipartition
print("\n[BLOC 7] H3 — Equipartition sin²theta=(1-s0)")
print("  sin²theta = V_g''<dy²>/V_g  (fraction énergie mode y)")
delsq=27.0/(8*np.pi**2*mFP2*VgF)
sin2=Vgpp_yt*delsq/VgF
chk("H3a", abs(delsq-0.09)<1e-10, f"<dy²>={delsq:.12f}  (attendu 0.09)")
chk("H3b", abs(sin2-(1-s0))<1e-12,f"sin²theta={sin2:.14f}=(1-s0)={1-s0:.14f}")

# Bloc 8 — H4 température
print("\n[BLOC 8] H4 — T_eff = sin²theta * T_dS")
print("  H_f=0 => T_dS^(f)=0 => seule composante g émet")
T_dS=hbar*H0_si/(2*np.pi*kB)
T_eff=sin2*T_dS
a0_U=2*np.pi*c*kB*T_eff/hbar
a0_P=c*H0_si*(1-s0)
chk("H4",abs(T_eff-(1-s0)*T_dS)<1e-40, f"T_eff={T_eff:.6e}K")
chk("7", abs(a0_U-a0_P)/a0_P<1e-8,
    f"g_N(r_t)={a0_P:.8e} m/s² = a0_BPB")

# Bloc 9 — contraintes
print("\n[BLOC 9] Compatibilité observationnelle")
chk("8a", mFP_eV<1.76e-23, f"m_FP={mFP_eV:.2e} << LIGO 1.76e-23 eV")
chk("8b", mFP_eV<1e-30,    f"m_FP={mFP_eV:.2e} << PPN  1e-30 eV")

# Score
n=len(PASS)+len(FAIL)
print(f"\n{'='*65}")
print(f"SCORE : {len(PASS)}/{n}  {'PASS' if not FAIL else 'FAIL'}")
print(f"m_FP = {mFP:.6f} H0 = {mFP_eV:.4e} eV")
print(f"g_N(r_t) = {a0_P:.8e} m/s2")
