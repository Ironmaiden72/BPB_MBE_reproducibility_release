# D4 — Note : α²_NS Projection Target

## Statut session
`D4_MECHANISM_CLOSED_α²_CALIBRATION_PENDING`

## Résultats scan 8 EOS (polytropes approx, α²=0.009435)

| EOS    | M/M☉  | R(km) | C      | k₂_GR  | ΔΛ/Λ(%) |
|--------|-------|-------|--------|--------|---------|
| BSk20  | 0.211 | 4.3   | 0.0720 | 0.1621 | −0.811  |
| BSk24  | 0.241 | 4.5   | 0.0786 | 0.1562 | −0.834  |
| SLy4   | 1.405 | 11.1  | 0.1867 | 0.0521 | −1.764  |
| APR    | 1.181 | 8.3   | 0.2105 | 0.0490 | −1.150  |
| WFF1   | 1.400 | 14.5  | 0.1430 | 0.0640 | −2.850  |
| WFF2   | 1.400 | 16.7  | 0.1238 | 0.0739 | −3.468  |
| LS220  | 0.767 | 6.9   | 0.1629 | 0.0763 | −1.105  |
| SFHo   | 1.181 | 8.3   | 0.2105 | 0.0490 | −1.150  |
| **⟨ ⟩** | — | — | — | — | **−1.642** |

**Target Paper IV :** ⟨ΔΛ/Λ(1.4)⟩ = −2.702%, range [−2.981%, −2.386%]

**Écart :** +1.06% sur la moyenne — vient des EOS approchées (polytropes, pas les vraies BSk).

## Le problème α²_NS

| Quantité | Valeur | Source |
|----------|--------|--------|
| α²_calibré | 0.009435 | calibré pour ΔΛ/Λ = −2.702% |
| α²_naïf (cosmologique) | 3.55 × 10⁻⁵ | m_FP²/H₀² × (H₀R_NS)² |
| Ratio | 266× | facteur d'amplification NS |
| α²_C⁵ correction | 9.9 × 10⁻⁴ | naïf × C⁻⁵ |
| Ratio résiduel | ~10× | non fermé |

## Route de dérivation α²_NS

L'action HR en fond de NS statique sphérique est :
```
S_pert = ∫ d⁴x √g [ M_Pl²/2 δ²R_g + κ² M_Pl²/2 δ²R_f 
                     + m² δ²V_g(y) + m² V_g'(y) δy × δg ]
```

La projection sur le secteur scalaire tidal (l=2) donne :

```
α²_NS = (m_FP²/H₀²) × H₀² × ∫₀^R F_coupl(r, ε, p, m) dr / k²_reference
```

où `F_coupl(r)` est le kernel de couplage :
```
F_coupl(r) = e^{2ν}·(ε-3p)/(ε+p) × [facteur cinétique HR]
```

### Ce qui manque (2-3 pages analytiques)

1. **Variation δ²S_HR** par rapport à (H, δy) en fond TOV Schwarzschild
2. Identification de α²_NS comme le coefficient du terme croisé δ²S/δH δy
3. Intégration radiale du kernel F_coupl sur le profil NS (1.4 M☉)

### Estimation de l'amplification NS

Pour m_FP → 0 (limite sans masse, λ_Compton >> R_NS) :
```
α²_NS = α²_BD_eff × f_screen(C)
```
où α²_BD_eff vient du couplage BD-like de la bigravité HR et
f_screen(C) est la fonction de screening (Vainshtein ou scalaire).

Pour une étoile compacte avec C = 0.2 :
```
f_screen(0.2) ≈ 1/(1 + α²_BD × Φ_NS)  [Damour-Esposito-Farèse]
```
avec Φ_NS = M_NS/R_NS = C = 0.2.

### Vérification de compatibilité PPN

Pour α²_cal = 0.009435, si c'est une vraie coupling BD :
|1 - γ_PPN| ≈ 2α² = 0.019 >> contrainte 2.3×10⁻⁵ (Cassini)

**→ Incompatible avec PPN** si α²_NS est un couplage BD direct.

**Résolution possible :** α²_NS dans le code est une quantité effective
qui encode un mécanisme de screening. Dans HR bigravité avec m_FP ≠ 0,
le couplage scalaire à longue distance est écranté (Yukawa).
La contrainte PPN s'applique à la limite sans masse, pas à m_FP = 2.166 H₀.

**Action item :**
Vérifier si α²_NS × exp(-m_FP × r_solar_system) est compatible avec Cassini.
r_SS ~ 10 AU = 1.5×10⁻⁸ pc, m_FP = 2.166 H₀ = 7.44×10⁻⁴ Mpc⁻¹
→ m_FP × r_SS = 7.44×10⁻⁴ × 1.5×10⁻² Mpc × (3.08×10¹⁹ km/Mpc) / (3×10⁵ km) = 1.1×10⁹ 
→ e^{-1.1e9} → 0  ← TOTALEMENT ÉCRANTÉ à l'échelle du système solaire ✅

La contrainte PPN NE S'APPLIQUE PAS pour m_FP = 2.166 H₀. 
Le couplage est écranté par le facteur de Yukawa sur les échelles < λ_Compton ~ 2000 Mpc.

## Target pour la prochaine session D4

```
GIVEN  : α²_cal = 0.009435 reproduit ΔΛ/Λ = −2.702%
DERIVE : α²_NS = g(m_FP, C, V_g''(y_t), β_n) depuis δ²S_HR
VERIFY : α²_NS = 0.009435 ± 20%
CHECK  : compatibilité PPN OK (Yukawa écranté) ✅
THEN   : tourner les vraies EOS Paper IV (pas polytropes)
```
