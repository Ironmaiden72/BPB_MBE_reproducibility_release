# D2 -- acceleration-scale closure, v0.7

**Status:** `D2_INTERNAL_SOURCE_LOCK_PASSED_V07`  
**Scope:** acceleration-scale descendant only.

D2 closes the bridge

```text
a0_BPB = c H0 (1 - s_surv0)
```

under the documented H1-H4 convention bundle. It does not claim full MOND action-level closure, a unique interpolation function, or a full SPARC rotation-curve likelihood.

## Core distinction

The rounded HR branch algebra gives

```text
s_surv,HR = (beta0+beta1)/Vg(y_t) = 0.648/0.810 = 0.800
sin^2(theta)_HR = DeltaOmega/Vg(y_t) = 0.162/0.810 = 0.200
```

The numerical corpus lock used for acceleration-scale propagation is

```text
s_surv,0 = 0.7956924397708606
1-s_surv,0 = 0.2043075602291394
```

The 2.15% difference in the complementary fraction is recorded as a source-lock correction between rounded HR branch algebra and the exact numerical corpus lock.

## Prediction

```text
m_FP/H0 = sqrt(27/(8*pi^2*y_t^2*Vg(y_t))) = 2.165824447871323
m_FP ~= 3.0711e-33 eV
```

With

```text
H0 = 68.91059068227626 km/s/Mpc
T_dS = hbar H0/(2*pi*kB) = 2.714866240842e-30 K
T_eff = (1-s_surv0) T_dS = 5.546676980150e-31 K
```

Unruh conversion gives

```text
a0_BPB = 2*pi*c*kB*T_eff/hbar = c H0 (1-s_surv0)
        = 1.367856592595e-10 m/s^2
```

## H1-H4 convention bundle

- H1: the conformal-time kinetic normalization is `Z_y = 3 M_Pl^2 a^2`; the xi factors cancel and there is no residual `y_t` multiplier.
- H3: the rounded HR mode fraction is `sin^2(theta)_HR = Vg'' <delta y^2>/Vg = 0.200`.
- H4: at the lower Bianchi point, the reduced branch-flow interpretation gives `H_f=0`, so `T_eff=(1-s_surv0)T_dS` in the exact numerical lock.

## Files

```text
scripts/D2_audit_complete.py     -- v0.7 audit, 18/18 assertions
scripts/H1_kinetic_derivation.py -- kinetic normalization note
scripts/H3_equipartition.py      -- rounded HR mode fraction
scripts/H4_temperature.py        -- exact thermal bridge
data/D2_scalars.json             -- scalar locks
notes/D2_closure_note.md         -- this note
```
