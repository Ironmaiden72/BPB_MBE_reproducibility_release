# Paper I v0.4.1 QA / hotfix

Status: `HAL_READY_HOTFIX_SOURCE_ONLY`

This is a minimal source-only hotfix on top of Paper I v0.4. It does not change any locked numerical result.

## Changes from v0.4

1. Clarified the status of `c_Σ = 0.71` in Section 4.4:
   - it is selected by the ACT Weyl-closure diagnostic;
   - it is fixed in the full-joint artefact;
   - it is still counted conservatively as an additional effective parameter for AIC/BIC.

2. Regenerated Figure 2 (`fig2_blockwise_delta.pdf/png`) to remove the textual `chi2` artefact and display the label as `Total Δχ² = -15.829`.

3. Kept Figure 4 / ablation-status as a release-style table figure. This remains acceptable for HAL; a future journal version may convert it into a native LaTeX table.

## Numerical lock preservation

No locked value is changed:

- BPB χ² = 1782.4420773237218
- LCDM χ² = 1798.2712190366963
- Δχ² = -15.829141712974518
- AIC/BIC discussion unchanged
- blockwise decomposition unchanged
- ACT diagnostic table unchanged
- core claim `μ_m ≠ Σ` unchanged

## Packaging

This ZIP intentionally excludes the compiled PDF. Compile locally from:

```bash
pdflatex paperI_lowz_BPB_MBE_v0_4_1.tex
bibtex paperI_lowz_BPB_MBE_v0_4_1 || true
pdflatex paperI_lowz_BPB_MBE_v0_4_1.tex
pdflatex paperI_lowz_BPB_MBE_v0_4_1.tex
```
