# Paper V v0.3.2 QA / source-only hotfix

## Status

`PAPER_V_V0_3_2_SOURCE_ONLY_HOTFIX_PASS`

## User-review items addressed

- Added the missing symmetric LCDM interpretation immediately after the raw-likelihood table/paragraph in Section 5.
- New body text states that LCDM achieves its better raw score with `log10 M_peak = 9.9965`, i.e. `2.51 sigma` below the mapper-physicality centre, while BPB reaches a comparable UV fit from `log10 M_peak = 10.891`, i.e. `1.02 sigma` below the centre.
- Added the explicit conclusion that, in this diagnostic, the raw LCDM advantage is partly purchased by an unphysical mapper location.
- Preserved the guardrail that this does not hide the raw score: the raw score and the data-plus-physicality score answer different questions.
- Updated version labels from v0.3.1 to v0.3.2.
- No scientific scalar values were changed.

## Numeric lock preserved

- Raw UVLF+rho-star: LCDM `11.2413`, BPB `13.5579`, delta `+2.3167` for BPB.
- Physical-peak magnitudes: LCDM about `-19.15`, BPB about `-19.19`.
- Host masses: LCDM `log10 M_peak = 9.9965`, BPB `log10 M_peak = 10.8910`.
- Host-mass shift: `0.8945 dex` / factor `7.84`.
- Data+prior: LCDM about `17.96`, BPB `16.06` / `16.0579` in locked scalar output.
- Tau proxy: BPB best `0.04675`, posterior median `0.04395`.

## Compile QA

- Local `pdflatex` compile run completed successfully.
- Second pass completed with no unresolved reference/citation warnings in the checked log.
- PDF is intentionally not included in this source-only package.

## Package contents

- `paperV_early_galaxies_v0_3_2.tex`
- `figs/`
- `data/`
- `scripts/`
- `release_index/`
- `paperV_v0_3_2_QA.md`

## Guardrail

Paper V remains a high-redshift gate paper, not a final UVLF Bayesian evidence paper, not a full reionization likelihood, and not an external calibration of the host-mass regularizer.
