# BPB/MBE stage-1 release QA

- Manifest rows: 11
- Claims index rows: 95
- TODO rows: 10
- Claim source-lock CSVs parsed: 20
- Additional synthetic source-lock claims: 5

## SHA256

| file | sha256 |
|---|---|
| 00_MANIFEST_CORPUS.csv | `300f8bacabf4f5bc618a765309f3e21d26789cbeba67d4d8d6bf250da20b34a4` |
| 00_CLAIMS_INDEX.csv | `7766d858e42d6333f2acfc1b7ea1fcea69d19b0f64c30d4284a4f8a86fd315b6` |
| 00_REVIEWER_ROUTE.md | `4972d8dfef441e3cc9f667859b62f7f14affe3b8099d418f34ad7ad1049d52d6` |
| 00_REVIEWER_ROUTE.csv | `681dd553a2af0e89e3404e173d77d1604fcab3ee8a818972a486f496dd0f0530` |
| 00_RELEASE_TODO.csv | `6ef2e8d87b4a4774db325fae5d2f46398eea4bdcfee05dd41c21c8a3d221d6bf` |
| 00_RELEASE_NOTES.md | `92375106a6763e29dd243399bdc0095a0e6d4bf841cad19b74244533405087f0` |
