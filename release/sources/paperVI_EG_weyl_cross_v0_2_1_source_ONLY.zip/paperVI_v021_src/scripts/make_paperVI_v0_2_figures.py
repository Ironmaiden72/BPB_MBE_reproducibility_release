from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

base = Path(__file__).resolve().parents[1]
figdir = base / 'figs'
figdir.mkdir(exist_ok=True)
eg = pd.read_csv(base / 'data' / 'eg_compressed_v0_1.csv')
kw = pd.read_csv(base / 'data' / 'k_windows_v0_1.csv')
rh = pd.read_csv(base / 'data' / 'response_hierarchy_v0_1.csv')

# Figure 1: E_G data vs prediction
x = np.arange(len(eg))
width = 0.35
plt.figure(figsize=(7.2,4.6))
plt.bar(x - width/2, eg['obs'], width, yerr=eg['sigma'], capsize=4, label='Observed')
plt.bar(x + width/2, eg['bpb_prediction'], width, label='BPB auto/cross')
plt.xticks(x, eg['bin'])
plt.ylabel(r'$E_G$')
plt.title(r'Compressed $E_G$ diagnostic: data vs BPB auto/cross closure')
plt.legend(frameon=False)
for i,row in eg.iterrows():
    plt.text(i+width/2, row['bpb_prediction']+0.015, f"{row['residual_sigma']:+.2f}$\\sigma$", ha='center', va='bottom', fontsize=9)
plt.tight_layout()
plt.savefig(figdir / 'fig1_eg_data_vs_prediction.pdf')
plt.savefig(figdir / 'fig1_eg_data_vs_prediction.png', dpi=220)
plt.close()

# Figure 2: k windows
plt.figure(figsize=(7.2,4.6))
y = np.arange(len(kw))
for i,row in kw.iterrows():
    plt.hlines(y=i, xmin=row['k_min_simple'], xmax=row['k_max_simple'], linewidth=7)
    plt.plot([row['k_min_simple'], row['k_max_simple']], [i,i], 'o')
plt.axvline(0.01, linestyle='--', linewidth=1, label=r'$k=0.01$')
plt.axvline(0.02, linestyle=':', linewidth=1.2, label=r'$k=0.02$')
plt.yticks(y, kw['bin'])
plt.xlabel(r'$k=\ell/\chi$ [Mpc$^{-1}$]')
plt.title(r'Simple $k=\ell/\chi$ diagnostic: no bin is ultra-low-$k$')
plt.legend(frameon=False)
plt.tight_layout()
plt.savefig(figdir / 'fig2_k_window_diagnostic.pdf')
plt.savefig(figdir / 'fig2_k_window_diagnostic.png', dpi=220)
plt.close()

# Figure 3: response hierarchy
vals = {r'$r_{W\delta}^{\rm free}$': 0.633563, r'$\sqrt{a_{\rm bg}}$': 0.635364, r'$\Sigma_{\rm cross}$': 0.65137, r'$\Sigma_{\rm auto}$': 1.028105}
plt.figure(figsize=(7.2,4.6))
plt.bar(list(vals.keys()), list(vals.values()))
plt.axhline(1.0, linestyle='--', linewidth=1, label='LCDM unity')
plt.ylabel('Effective response')
plt.title(r'Auto/cross Weyl-response hierarchy and projected closure')
plt.legend(frameon=False)
for i,(k,v) in enumerate(vals.items()):
    plt.text(i, v+0.035, f'{v:.3f}', ha='center')
plt.ylim(0,1.18)
plt.tight_layout()
plt.savefig(figdir / 'fig3_response_hierarchy.pdf')
plt.savefig(figdir / 'fig3_response_hierarchy.png', dpi=220)
plt.close()

# Figure 4: auto/cross schematic
plt.figure(figsize=(8.2,4.7))
ax=plt.gca()
ax.axis('off')
# boxes
boxes = [
    (0.08,0.62,'Weyl auto sector\nACT / Planck lensing\n$P_{WW}=\\Sigma_{auto}^2P_{\\delta\\delta}$'),
    (0.58,0.62,'Weyl-matter cross\n$E_G$ / lensing-galaxy\n$P_{W\\delta}=r_{W\\delta}\\Sigma_{auto}P_{\\delta\\delta}$'),
    (0.32,0.15,'Matter/growth sector\n$\\mu_m$, $f\\sigma_8$, RSD\nnot a universal $\\Sigma$')
]
for x0,y0,text in boxes:
    rect = plt.Rectangle((x0,y0),0.34,0.22, fill=False, linewidth=1.5)
    ax.add_patch(rect)
    ax.text(x0+0.17,y0+0.11,text,ha='center',va='center',fontsize=10)
# arrows
ax.annotate('', xy=(0.58,0.73), xytext=(0.42,0.73), arrowprops=dict(arrowstyle='->', lw=1.5))
ax.text(0.50,0.77,r'$r_{W\delta}^{\rm free}=0.6336\simeq\sqrt{a_{\rm bg}}$',ha='center',fontsize=10)
ax.annotate('', xy=(0.43,0.37), xytext=(0.24,0.62), arrowprops=dict(arrowstyle='->', lw=1.2))
ax.annotate('', xy=(0.57,0.37), xytext=(0.72,0.62), arrowprops=dict(arrowstyle='->', lw=1.2))
ax.text(0.50,0.05,r'Paper VI claim: $\mu_m \neq \Sigma_{auto} \neq \Sigma_{cross}$',ha='center',fontsize=12)
plt.tight_layout()
plt.savefig(figdir / 'fig4_auto_cross_schematic.pdf')
plt.savefig(figdir / 'fig4_auto_cross_schematic.png', dpi=220)
plt.close()

print('Figures written to', figdir)
