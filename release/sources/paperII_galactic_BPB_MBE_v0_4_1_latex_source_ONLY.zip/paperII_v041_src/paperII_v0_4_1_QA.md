# Paper II v0.4.1 QA / hotfix changelog

## Status

`paperII_galactic_BPB_MBE_v0_4_1.tex` compiles successfully with `pdflatex` in the local environment.  The user-facing ZIP is source-only and intentionally excludes the compiled PDF.

## Changes relative to v0.4

1. Active-sample vulnerability patched in Section 5.1:
   - parent SPARC catalog size stated explicitly: 175 galaxies;
   - active sign/null audit sample stated explicitly: 38 galaxies;
   - excluded count stated explicitly: 137 galaxies;
   - reason stated: the frozen Paper-II pipeline does not provide the complete finite tuple required for this audit: reference NFW halo, required correction amplitude A_req, outer-slope diagnostic m_out, and response-kernel columns.

2. Appendix labeling fixed:
   - `Data and reproducibility inventory` is now an unstarred appendix section with label `app:repro_inventory`.
   - `Version notes` is now an unstarred appendix section with label `app:version_notes`.

3. Permutation notation standardized:
   - active sign-rule p-value is consistently written as `p_perm = 0.00014`.
   - D6 permutation lower bound remains separately written as `p = 1/5001`.

4. MOND/RAR comparison references added:
   - Milgrom 1983;
   - McGaugh, Lelli & Schombert 2016 RAR paper.
   - Discussion text explicitly states that Paper II is not a MOND interpolation-function fit and does not infer a universal acceleration scale from SPARC.

5. Figure packaging clarified:
   - figures remain inline TikZ/PGFPlots inside the `.tex` source;
   - added `figures_source_notes/INLINE_TIKZ_FIGURES.md`.

## Numerical invariance

No scientific numbers were changed.  Locked values remain:

- sign rule: 33/38;
- sign-rule p_perm: 0.00014;
- sign-rule Z: 4.059;
- calibrated archived-response RC delta chi2: -4605.230;
- oracle gap: 8.340;
- D5 raw RC delta chi2: -4302.455768;
- D5 recovered gap fraction: 0.773245;
- D6 permutation lower bound: p = 1/5001;
- D7 CAMB tilt slopes: TT = 0.008945, EE = 0.009453.

## Compile command

```bash
pdflatex -interaction=nonstopmode paperII_galactic_BPB_MBE_v0_4_1.tex
pdflatex -interaction=nonstopmode paperII_galactic_BPB_MBE_v0_4_1.tex
```
