# Paper II v0.4.1 figure note

The figures in `paperII_galactic_BPB_MBE_v0_4_1.tex` are intentionally generated inline with TikZ/PGFPlots.

There is no required external `figures/` directory for compilation.  The source contains the plotting instructions directly for the main visual checks:

- kernel forensic / positive-tail recovery
- W2 collapse-to-morphology check
- fixed sign-rule accuracy and permutation-Z panels
- decisive-galaxy response comparison
- rotation-curve chi2 hierarchy
- self-calibrated response comparison

This is source-only and arXiv/HAL-friendly: compile the `.tex` file with a LaTeX installation including TikZ/PGFPlots.
